package iitb.CRF;

import iitb.Model.FeatureGenImpl;
import iitb.Tagging.DCTrainRecord;

import java.io.*;
import java.lang.reflect.Constructor;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.ListIterator;

/**
 *
 * CRF (conditional random fields) This class provides support for
 * training and applying a conditional random field for sequence
 * labeling problems.   
 *
 * @author Sunita Sarawagi
 *
 */ 


public class CRF implements Serializable {
    /**
     * Comment for <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = 14L;
    double lambda[];
    public int numY;
    transient Trainer trainer;
    FeatureGenerator featureGenerator; 
    public CrfParams params;
    public  FeatureGenImpl featureGen;
    /**
     * @param numLabels is the number of distinct class labels or y-labels
     * @param fgen is the class that is responsible for providing 
     * the features for a particular position on the sequence.
     * @param arg is a string that can be used to control various 
     * parameters of the CRF, these are space separated name-value pairs 
     * described in 
     * @see iitb.CRF.CrfParams 
     */
    public CRF(int numLabels, FeatureGenerator fgen, String arg) {
        this(numLabels, fgen, CrfParams.stringToOptions(arg));
    }
    
    public CRF(int numLabels, FeatureGenerator fgen, java.util.Properties configOptions) {
        this(numLabels,1,fgen,configOptions);
    }
    
    public CRF(int numLabels, int histsize, FeatureGenerator fgen, java.util.Properties configOptions) {
        featureGenerator = fgen;
        numY = fgen.numFeatures();
        params = new CrfParams(configOptions);
    }
    public CRF(int numLabels, int histsize, FeatureGenImpl fgen, java.util.Properties configOptions) {
    	featureGen = fgen;
        numY = fgen.numFeatures();
        params = new CrfParams(configOptions);
    }
    
    
    
    public FeatureGenerator getFeatureGenerator() {return featureGenerator;}
    /*
     * useful for resetting Viterbi options after loading a saved model.
     */
    public void reinitOptions(java.util.Properties configOptions) {
	params = new CrfParams(configOptions);
    }
    /**
     * write the trained parameters of the CRF to the file
     */
    public void write(String fileName)  throws IOException {
        PrintWriter out=new PrintWriter(new FileOutputStream(fileName));
        out.println(lambda.length);
        for (int i = 0; i < lambda.length; i++)
            out.println(lambda[i]);
        out.close();
    }
    /**
     * read the parameters of the CRF from a file
     */
    public void read(String fileName) throws IOException {
        BufferedReader in=new BufferedReader(new FileReader(fileName));
        int numF = Integer.parseInt(in.readLine());
        lambda = new double[numF];
        int pos = 0;
        String line;
        while((line=in.readLine())!=null) {
            lambda[pos++] = Double.parseDouble(line);
        }
    }
    protected Trainer dynamicallyLoadedTrainer() {
        if (params.trainerType.startsWith("load=")) {
            try {
                Class c =  Class.forName(params.trainerType.substring(5));
                Constructor constr = c.getConstructor( new Class[] { CrfParams.class } );
                return (Trainer)constr.newInstance( new Object[] { params } );
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return null;
            }
        }
        return null;
    }
    protected Trainer getTrainer() {
        
        return new Trainer(params);
    }

    /**
     * Trains the model given the data
     * @return the learnt parameter value as an array
     */
    public double[] train(DataIter trainData) {
        return train(trainData,null,null);
    }
    public void setInitTrainWeights(double initLambda[]) {
        lambda = new double[featureGenerator.numFeatures()];
        params.miscOptions.setProperty("initValuesUseExisting", "true");
        for (int i = 0; i < initLambda.length; lambda[i] = initLambda[i], i++);
    }
    /**
     * Trains the model given the data
     * @return the learnt parameter value as an array
     */
    public double[] train(DataIter trainData, Evaluator evaluator) {
        return train(trainData,evaluator,null);
    }
    /**
     * Trains the model given the data with weighted instances.
     * @return the learnt parameter value as an array
     */
    public double[] train(DataIter trainData, Evaluator evaluator, float instanceWts[]) {
        if (lambda == null) lambda = new double[featureGen.grammermapLambda.size()];	
        trainer = getTrainer();
        trainer.featureGen = featureGen;
        trainer.train(this, trainData, lambda, evaluator, instanceWts);
        return lambda;
    }
    /** 
     * Same as above except that there is a misclassification cost associated with label pairs.
     */
    public double[] train(DataIter trainData, Evaluator evaluator, float instanceWts[], float misClassCosts[][]) {
        if (lambda == null) lambda = new double[featureGenerator.numFeatures()];    
        trainer = getTrainer();
        trainer.train(this, trainData, lambda, evaluator, instanceWts, misClassCosts);
        return lambda;
    }
    public double[] learntWeights() {
        return lambda;
    }
    LinkedList  getToken_CKY( DCTrainRecord dataSeq, int i) 
    {
 	   
    	
      LinkedList re =  new LinkedList();
      
  	  Hashtable<Integer,Integer>temp =featureGen.lexicalrulemaplambda((DCTrainRecord)dataSeq,i);
  	   
  	 
  					   for (Enumeration e1 = temp.keys(); e1.hasMoreElements();) 
  					   {
  						   
  						   Integer key1 = (Integer)e1.nextElement();
  						   CKYEntry  entry = new CKYEntry();
  						   entry.ID =  key1;
  						   entry.value =  (lambda[temp.get(key1).intValue()]);
  						   entry.middle =(short)i;
  						   re.add(entry);
  						   	   
  					   }
  	   return re;
  	   
  	  //  ��򵥵�ʵ��
     }
    
    
    LinkedList CKY_Array[][];
    
    class CKYEntry
    {
    	short middle;
    	int ID;
    	double value;
    	int body0;
    	int body1;
    };
    
    protected void  initCKY(DataSequence dataSeq)
    {
	    CKY_Array  = (LinkedList[][])new LinkedList[dataSeq.length()][dataSeq.length()];
	   for(int i=0;i<dataSeq.length();i++)
	   {
		   CKY_Array[i][i] = getToken_CKY((DCTrainRecord)dataSeq,i);
	   } 
	     
    }
    
    protected  CKYEntry CKY_ArrayGet( LinkedList list, int head)
    {
    	if(list==null)
    	{
    		return null;
    	}
    	
    	ListIterator<CKYEntry> e1 = list.listIterator();
    	while (e1.hasNext()) {
    		
    		CKYEntry value = e1.next();
    		 if(value.ID == head)
    		 {
    			 return value;
    			 
    		 }
    	}
    	return null;
    	
    	
    }    
    
    public double CKY(DCTrainRecord dataSeq)
    {
    	CKYEntry key1;
    	CKYEntry key2;
    	
    	initCKY(dataSeq);
    	
    	for (int k = 1; k < dataSeq.length(); k++) {

			for (int i = 0; i < dataSeq.length() - k; i++) {
				int j = i + k;
				for (int m = i; m < j; m++) {
					if (CKY_Array[i][m] != null
							&& CKY_Array[m + 1][j] != null)
						for (ListIterator<CKYEntry> e1 = CKY_Array[i][m].listIterator();e1.hasNext();) {
							key1 = (CKYEntry) e1.next();
							for (ListIterator<CKYEntry> e2 = CKY_Array[m + 1][j].listIterator(); e2.hasNext();) {
								key2 =  (CKYEntry) e2.next();
								long key;
								double valueA;
								double valueB;

								valueA = key1.value;
								valueB = key2.value;

								key = featureGen.grammerMapsGetKey(key1.ID, key2.ID,
										0);
								LinkedList list = featureGen.grammerMaps
										.get(new Long(key));
								if (list == null) {
									continue;

								}
								ListIterator<Integer> E = list.listIterator();
								while (E.hasNext()) {
								int 	rulehead = E.next();
								 CKYEntry 	 value;     
								       if(CKY_Array[i][j]==null)
								       {
								    	   CKY_Array[i][j] =  new LinkedList();
								       }
								        if((value=CKY_ArrayGet(CKY_Array[i][j],rulehead))==null)
								        {
								        	value = new CKYEntry();
								        	value.ID = rulehead;
								        	value.middle = (short) m;
								        	value.body0 = key1.ID;
								        	value.body1 = key2.ID;
								        	value.value = key1.value+key2.value+lambda[featureGen.rulemaplambda(dataSeq, i, j, m, rulehead, key1.ID,key2.ID)];
								        	CKY_Array[i][j].add(value);
								        }else
								        {
								        	double temp = key1.value+key2.value+lambda[featureGen.rulemaplambda(dataSeq, i, j, m, rulehead, key1.ID,key2.ID)];
								        	if(value.value<temp)
								        	{
								        		
								        		value.middle = (short) m;
									        	value.body0 = key1.ID;
									        	value.body1 = key2.ID;
									        	value.value = temp;
								        		
								        	}
								        	
								        	
								        }						
								}
							}
						}
				}
			}
    	}
			
    	
    	return 0.0;//to do 
    }
    static int [][] tokengrammerLocation = new int[1024*4*4][];
    CKYEntry array[] = new CKYEntry [1024*4*4];
    int  location [][] = new int[1024*4*4][2];
    static int tokengrammerindex  = 0;
        int [][] GetBestTagging()
        {
        	tokengrammerLocation [0] = new int[3]; 
        	int [][]bestTagging;
        	array[0]=null;
        	for (ListIterator<CKYEntry> e1 = CKY_Array[0][CKY_Array.length-1].listIterator();e1.hasNext();) 
        	{
        		
        		
        		 if(array[0]==null)
        		  {
        			  array[0] = e1.next();
        			  
        		  }else
        		  {
        			  CKYEntry temp = e1.next();	  
        			  if(array[0].value<temp.value&&featureGen.root.get(temp.ID)!=null)
        			  {
        				  array[0] = temp;
        				   
        			  }
        		  }
        	}
        	tokengrammerindex = 1;
        	 if(  array[0]==null )
             {
            	 return null;
            	 
             }
        	location[0][0] = 0;
        	location[0][1] = CKY_Array.length-1;
        	for(int i =0;i<tokengrammerindex;i++)
        	{
        		
        		if(location[i][0]!=location[i][1])
        		{
        			tokengrammerLocation[i] = new int[3];     			                        
        			tokengrammerLocation[i][0] = array[i].ID;
        			tokengrammerLocation[i][1] = tokengrammerindex;
        			tokengrammerLocation[i][2] = tokengrammerindex+1;
        			location[tokengrammerindex][0] =  location[i][0];
        			location[tokengrammerindex][1] =  array[i].middle;
        			location[tokengrammerindex+1][0] = array[i].middle+1;
        			location[tokengrammerindex+1][1] = location[i][1];
        			array[tokengrammerindex] = CKY_ArrayGet(CKY_Array[location[tokengrammerindex][0]][location[tokengrammerindex][1]],array[i].body0);
        			array[tokengrammerindex+1] = CKY_ArrayGet(CKY_Array[location[tokengrammerindex+1][0]][location[tokengrammerindex+1][1]],array[i].body1);
        			tokengrammerindex = tokengrammerindex+2;
        			
        		}else
        		{
        			tokengrammerLocation[i] = new int[2]; 
        			tokengrammerLocation[i][0] = array[i].ID;
        			tokengrammerLocation[i][1] = array[i].middle;
        		}
        		
        		
        	}
        	
        	bestTagging = new int[tokengrammerindex][];
        	for(int i =0;i<tokengrammerindex;i++)
        	{
        	
        		bestTagging[i] = tokengrammerLocation[i];
        		
        	}
        	return bestTagging;
        	
        }
    
    
    public void apply(DCTrainRecord dataSeq) {
      
    	   DCTrainRecord DataSeq  = dataSeq;
    	   CKY((DCTrainRecord )dataSeq);
    	   dataSeq.ls = GetBestTagging();
    	 
    }
    
 

 
    public int getNumY() {return numY;}
};
