/** Trainer.java
 * 
 * @author Sunita Sarawagi
 * @version 1.3 
 */
package iitb.CRF;

import iitb.Model.FeatureGenImpl;
import iitb.Model.TagWordsInTrain.HEntry;
import iitb.Tagging.DCTrainRecord;

import java.awt.List;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.StringTokenizer;

import riso.numerical.LBFGS;
import cern.colt.function.DoubleDoubleFunction;
import cern.colt.function.DoubleFunction;
import cern.colt.matrix.DoubleMatrix1D;
import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.DoubleMatrix3D;
import cern.colt.matrix.impl.DenseDoubleMatrix1D;
import cern.colt.matrix.impl.DenseDoubleMatrix2D;
/**
 *
 * @author Sunita Sarawagi
 *
 */ 

public class Trainer {
    protected int numF,numY;
    protected double gradLogli[];
    double diag[];
    protected double lambda[];
    protected boolean reuseM, initMDone=false, logProcessing=false;
    
    protected double ExpF[], lZx;
    double scale[], rLogScale[];
    FeatureGenImpl featureGen;
    
    protected DoubleMatrix2D Mi_YY;
    protected DoubleMatrix1D Ri_Y;
    protected DoubleMatrix1D alpha_Y, newAlpha_Y;
    protected DoubleMatrix1D beta_Y[];
    protected DoubleMatrix1D tmp_Y; 
    protected Hashtable<Long,Hashtable<Short, Integer>> grammerRoots;// terminal alphabet -> nonterminal alphabets
    protected  Hashtable<Integer,Double>alpha_Inside[][];
    protected  Hashtable<Integer,Double>beta_Outside[][];
    protected  double SmoothCoefficient = 0.1;
    /* Normal forms*/
    
    
    static class  MultFunc implements DoubleDoubleFunction {
        public double apply(double a, double b) {return a*b;}
    };
    static class  SumFunc implements DoubleDoubleFunction {
        public double apply(double a, double b) {return a+b;}
    };
    static MultFunc multFunc = new MultFunc(); 
    protected static SumFunc sumFunc = new SumFunc(); 
    
    class MultSingle implements DoubleFunction {
        public double multiplicator = 1.0;
        public double apply(double a) {return a*multiplicator;}
    };
    MultSingle constMultiplier = new MultSingle();
    
    protected DataIter diter;
    protected FeatureGenerator featureGenerator;
    protected CrfParams params;
    protected int icall;
    protected float instanceWts[];
    Evaluator evaluator = null;
    
    
    protected double norm(double ar[]) {
        double v = 0;
        for (int f = 0; f < ar.length; f++)
            v += ar[f]*ar[f];
        return Math.sqrt(v);
    }
    public Trainer(CrfParams p) {
        params = p; 
    }
    public void train(CRF model, DataIter data, double[] l, Evaluator eval) {
        trainInternal(model,data,l,eval,null,null);
    }
    public void train(CRF model, DataIter data, double[] l, Evaluator eval, float[] instanceWts) {
        if (instanceWts==null) {
            // this is to ensure backward compatibility with trainers who might have overridden the above function.
            train(model,data,l,eval);
            return;
        }
        trainInternal(model,data,l,eval,instanceWts,null);
    }
    public void train(CRF model, DataIter data, double[] l, Evaluator eval, float[] instanceWts, float misClassifyCost[][]) {
        if ((instanceWts==null) && (misClassifyCost==null)) {
            // this is to ensure backward compatibility with trainers who might have overridden the above function.
            train(model,data,l,eval);
            return;
        }
        trainInternal(model,data,l,eval,instanceWts, misClassifyCost);
    }
    // this last argument is ignored for logistic trainers on sequence data.
    private void trainInternal(CRF model, DataIter data, double[] l, Evaluator eval, float[] instanceWts, float misClassifyCost[][]) {
        init(model,data,l);
        evaluator = eval;
        this.instanceWts = instanceWts;
        if (params.debugLvl > 0) {
            Util.printDbg("Number of features :" + lambda.length);      
        }
        doTrain(model);

    }
    
    protected void setInitValue(double lambda[]) {
        if (params.miscOptions.getProperty("initValues") != null) {
            // starting values stored in a file where each line has (featureName, value) pair
            String fname = params.miscOptions.getProperty("initValues");
            BufferedReader in;
            try {
                in = new BufferedReader(new FileReader(fname));
            
            String line;
            boolean idOrdered=Boolean.parseBoolean(params.miscOptions.getProperty("initValuesOrdered", "false"));
            Hashtable<String, Double> initVals = new Hashtable<String, Double>();
            for(int l = 0; ((line=in.readLine())!=null); l++) {
                StringTokenizer entry = new StringTokenizer(line);
                String featureName = entry.nextToken();
                double fval = Double.parseDouble(entry.nextToken());
                if (!idOrdered) 
                    initVals.put(featureName,fval);
                else
                    lambda[l] = fval;
            }
            if (!idOrdered) {
            for (int j = 0 ; j < lambda.length ; j ++) {
                String featureName = featureGenerator.featureName(j);
                lambda[j] = (initVals.get(featureName) != null)?initVals.get(featureName):getInitValue();
            }
            }
            return;
            } catch (IOException e) {
                e.printStackTrace();
                System.err.println("ERROR: in file initialization, using default init process");
            }
        } else if (Boolean.parseBoolean(params.miscOptions.getProperty("initValuesUseExisting", "false"))) {
            // use existing values of lambda from the model as starting point.
            return;
        } else
        for (int j = 0 ; j < lambda.length ; j ++) {
            lambda[j] = getInitValue();
        }
    }
    double getInitValue() { 
        return params.initValue;
    }
    protected void init(CRF model, DataIter data, double[] l) {
        lambda = l;
        numY = model.numY;
        diter = data;
        featureGen = model.featureGen;
        numF = featureGen.numFeatures();
        
        gradLogli = new double[numF];
        diag = new double [ numF ]; // needed by the optimizer
        ExpF = new double[lambda.length];
        reuseM = params.reuseM;
        if (params.trainerType.equals("ll"))
            logProcessing=true;
        
    }
 
    
   protected Hashtable<Integer,Double > getToken_alpha(DataSequence dataSeq,int i)
   {
	   
	
	  
	  Hashtable<Integer,Integer>temp =featureGen.lexicalrulemaplambda((DCTrainRecord)dataSeq,i);
	  
	   Hashtable<Integer,Double>re = new Hashtable<Integer,Double>(); 
	   {
	 
					   for (Enumeration e1 = temp.keys(); e1.hasMoreElements();) 
					   {
						   Integer key1 = (Integer)e1.nextElement();
							   re.put(key1,expE(lambda[temp.get(key1).intValue()]));	
					   }
	   return re;
	   }
	  //  ��򵥵�ʵ��
   }
   protected Hashtable<Integer,Double> getToken_beta(DataSequence dataSeq)
   {
	   
	   Hashtable<Integer,Double> result = new Hashtable();
	   
	   result.put(((DCTrainRecord)dataSeq).ls[((DCTrainRecord)dataSeq).ls.length-1][0],1.0);
	   
	    return  featureGen.root;
	//   return  result;
	   
	   
   }
   
   protected void  initInsideOutside(DataSequence dataSeq)
    {
	   alpha_Inside = (Hashtable<Integer,Double>[][])new Hashtable[dataSeq.length()][dataSeq.length()];
	   beta_Outside = (Hashtable<Integer,Double>[][])new Hashtable[dataSeq.length()][dataSeq.length()];
	   for(int i=0;i<dataSeq.length();i++)
	   {
		  alpha_Inside[i][i] = getToken_alpha(dataSeq,i);
	   } 
	     
	      beta_Outside[0][dataSeq.length()-1] = getToken_beta(dataSeq);
	   
    }
   class featureEntry
   {
	  int head;
	  int body0;
	  int body1;
	  int lambdaId;
	  long location; 
   }
   LinkedList  featureCollect = new LinkedList();
   
   protected  int rulemaplambda(DataSequence dataSeq,int i,int j ,int m,int head,int body0,int body1)
   {
	   
	  return  featureGen.rulemaplambda(dataSeq,i,j,m,head,body0,body1);
	  
   }
    protected void InsideOutside(DataSequence dataSeq) {
		int dataseqLength = dataSeq.length();
		Integer rulebody[] = new Integer[2];
		rulebody[0] = new Integer((int) 0);
		rulebody[1] = new Integer((int) 0);

		Integer rulehead;
		long rule;// [] = new short[3];
		Integer key1 = new Integer((short) 0);
		Integer key2 = new Integer((short) 0);
		initInsideOutside(dataSeq);

		for (int k = 1; k < dataseqLength; k++) {

			for (int i = 0; i < dataseqLength - k; i++) {
				int j = i + k;
				for (int m = i; m < j; m++) {
					if (alpha_Inside[i][m] != null
							&& alpha_Inside[m + 1][j] != null)
						for (Enumeration e1 = alpha_Inside[i][m].keys(); e1
								.hasMoreElements();) {
							key1 = (Integer) e1.nextElement();
							for (Enumeration e2 = alpha_Inside[m + 1][j].keys(); e2
									.hasMoreElements();) {
								key2 = (Integer) e2.nextElement();
								long key;
								double valueA;
								double valueB;

								valueA = alpha_Inside[i][m].get(key1);
								valueB = alpha_Inside[m + 1][j].get(key2);

								key = featureGen.grammerMapsGetKey(key1, key2,
										0);
								LinkedList list = featureGen.grammerMaps
										.get(new Long(key));
								if (list == null) {
									continue;

								}
								ListIterator<Integer> E = list.listIterator();
								while (E.hasNext()) {
									rulehead = E.next();
									if (rulehead == null) {
										continue;
									} else {
										if (alpha_Inside[i][j] == null) {
											alpha_Inside[i][j] = new Hashtable<Integer, Double>();

										}

										Double value = alpha_Inside[i][j]
												.get(rulehead);

										rulebody[0] = key1;
										rulebody[1] = key2;

										// ;
										if (value == null) {
											value = new Double(
													expE(lambda[rulemaplambda(
															dataSeq, i, j, m,
															rulehead,
															rulebody[0],
															rulebody[1])])
															* valueB * valueA);
											alpha_Inside[i][j].put(rulehead,
													value);
										} else {
											value = expE(lambda[rulemaplambda(
													dataSeq, i, j, m, rulehead,
													rulebody[0], rulebody[1])])
													* valueB
													* valueA
													+ value.doubleValue();
											alpha_Inside[i][j].put(rulehead,
													value);

										}
									}
								}
							}
						}
				}
			}
		}
		;
		for (int k = 1; k < dataseqLength; k++) {
			int j;
			Double valueA;
			Double valueB;
			long key;

			for (int i = 0; i <= k; i++) {
				j = dataseqLength - 1 - k + i;
				for (int m = j + 1; m < dataseqLength; m++) {

					// i m
					// j+1 m

				
					
					
					if (beta_Outside[i][m] != null
							&& alpha_Inside[j + 1][m] != null)
						for (Enumeration e1 = beta_Outside[i][m].keys(); e1
								.hasMoreElements();) {
							key1 = (Integer) e1.nextElement();
							for (Enumeration e2 = alpha_Inside[j + 1][m].keys(); e2
									.hasMoreElements();) {
								key2 = (Integer) e2.nextElement();
								valueA = beta_Outside[i][m].get(key1);
								valueB = alpha_Inside[j + 1][m].get(key2);
								if (valueA == null || valueB == null) {
									continue;
								}
								key = featureGen.grammerMapsGetKey(key1, key2,
										2);
								LinkedList list = featureGen.grammerMaps
										.get(new Long(key));

								if (list == null) {
									continue;

								}

								ListIterator<Integer> E = list.listIterator();
								while (E.hasNext()) {
									rulebody[0] = E.next();
									if (rulebody[0] == null) {
										continue;
									} else {
										if (beta_Outside[i][j] == null) {
											beta_Outside[i][j] = new Hashtable<Integer, Double>();
										}

										Double value = beta_Outside[i][j]
												.get(rulebody[0]);
										rulehead = key1;
										rulebody[1] = key2;

										if (value == null) {

											value = new Double(
													expE(lambda[rulemaplambda(
															dataSeq, i, j, m,
															rulehead,
															rulebody[0],
															rulebody[1])])
															* valueB
																	.doubleValue()
															* valueA
																	.doubleValue());
											beta_Outside[i][j].put(rulebody[0],
													value);
										} else {
											value = expE(lambda[rulemaplambda(
													dataSeq, i, j, m, rulehead,
													rulebody[0], rulebody[1])])
													* valueB.doubleValue()
													* valueA.doubleValue()
													+ value.doubleValue();
											beta_Outside[i][j].put(rulebody[0],
													value);

										}

									}
								}

							}
						}

				}
				for (int m = i - 1; m >= 0; m--) {
					// m i-1
					// m j
					
					
					if (beta_Outside[m][j] != null
							&& alpha_Inside[m][i - 1] != null)
						for (Enumeration e1 = beta_Outside[m][j].keys(); e1
								.hasMoreElements();) {
							key1 = (Integer) e1.nextElement();
							for (Enumeration e2 = alpha_Inside[m][i - 1].keys(); e2
									.hasMoreElements();) {
								key2 = (Integer) e2.nextElement();

								valueA = beta_Outside[m][j].get(key1);
								valueB = alpha_Inside[m][i - 1].get(key2);

								key = featureGen.grammerMapsGetKey(key1, key2,
										1);
								LinkedList list = featureGen.grammerMaps
										.get(new Long(key));
								if (list == null) {
									continue;

								}
								ListIterator<Integer> E = list.listIterator();
								while (E.hasNext()) {
									rulebody[1] = E.next();
									if (rulebody[1] == null) {
										continue;
									} else {

										if (beta_Outside[i][j] == null) {
											beta_Outside[i][j] = new Hashtable<Integer, Double>();
										}

										Double value = beta_Outside[i][j]
												.get(rulebody[1]);
										rulehead = key1;
										rulebody[0] = key2;

										if (value == null) {

											value = new Double(
													(expE(lambda[rulemaplambda(
															dataSeq, i, j, m,
															rulehead,
															rulebody[0],
															rulebody[1])])
															* valueB
																	.doubleValue() * valueA
															.doubleValue()));
											beta_Outside[i][j].put(rulebody[1],
													value);
										} else {
											value = value
													+ expE(lambda[rulemaplambda(
															dataSeq, i, j, m,
															rulehead,
															rulebody[0],
															rulebody[1])])
													* valueB.doubleValue()
													* valueA.doubleValue();
											beta_Outside[i][j].put(rulebody[1],
													value);

										}

									}

								}
							}
						}
				}
			}
		}
	}
    protected void doTrain(CRF model) {
        double f, xtol = 1.0e-16; // machine precision
        int iprint[] = new int [2], iflag[] = new int[1];
        icall=0;
        
        iprint [0] = params.debugLvl-2;
        iprint [1] = params.debugLvl-1;
        iflag[0]=0;
        double variables[] = lambda;
        boolean positiveConstraint = params.miscOptions.getProperty("prior", "gaussian").equals("exp");
        if (positiveConstraint) {
            variables = new double[lambda.length];
        }
        
        setInitValue(variables);
        
        do {  
        	 long time = System.currentTimeMillis();
            if (positiveConstraint) {
                for (int i = 0; i < variables.length; i++) {
                    lambda[i] = Math.exp(variables[i]);
                }
                f = computeFunctionGradient(lambda,gradLogli); 
                for (int i = 0; i < gradLogli.length; i++) {
                    gradLogli[i] *= Math.exp(variables[i]);
                }
            } else {
                f = computeFunctionGradient(lambda,gradLogli); 
            }
            f = -1*f; // since the routine below minimizes and we want to maximize logli
            for (int j = 0 ; j < lambda.length ; j ++) {
                gradLogli[j] *= -1;
            } 
            
            if ((evaluator != null) && (evaluator.evaluate() == false))
                break;
            try	{
                LBFGS.lbfgs (numF, params.mForHessian, variables, f, gradLogli, false, diag, iprint, params.epsForConvergence, xtol, iflag);
            } catch (LBFGS.ExceptionWithIflag e)  {
                System.err.println( "CRF: lbfgs failed.\n"+e );
                if (e.iflag == -1) {
                    System.err.println("Possible reasons could be: \n \t 1. Bug in the feature generation or data handling code\n\t 2. Not enough features to make observed feature value==expected value\n");
                }
                return;
            }
            icall += 1;
            
            System.out.println("icall = "+ icall + "  time = " + (System.currentTimeMillis()-time) + "ms");
            if(icall%30==0)
            {
            	model.lambda = lambda;
            	try {
					model.write("/learntModels/features");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        } while (( iflag[0] != 0) && (icall <= params.maxIters));
    }
    protected double computeFunctionGradient(double lambda[], double grad[]) {
        return computeFunctionGradient(lambda,grad,null,featureGenerator);
    }
    protected double finishGradCompute(double grad[], double lambda[], double logli) {
        return logli;
    }
    protected double computeFunctionGradient(double lambda[], double grad[], double expFVals[], 
            FeatureGenerator fgenForExpValCompute) {    
        try {
            double logli = 0;
            if (grad != null) {
            	
            	  for (int f = 0; f < lambda.length; f++) {
                      grad[f] =  - (SmoothCoefficient*SmoothCoefficient*lambda[f])/2;
                      logli = logli - SmoothCoefficient*lambda[f];
                  }
                 }
            diter.startScan();
            initMDone=false;
            int numRecord;
            for (numRecord = 0; diter.hasNext(); numRecord++) {
                if (params.debugLvl > 1)
                    Util.printDbg("Read next seq: " + numRecord + " logli " + logli); 
                logli += sumProduct(diter.next(),featureGenerator,lambda,grad,expFVals,
                        false, numRecord, fgenForExpValCompute);
            }     
            logli = finishGradCompute(grad,lambda,logli);
            if (params.debugLvl > 2) {
                for (int f = 0; f < lambda.length; f++)
                    System.out.print(lambda[f] + " ");
                System.out.println(" :x");
                for (int f = 0; f < lambda.length; f++)
                    System.out.println(f + " " + featureGenerator.featureName(f) + " " + grad[f] + " ");
                System.out.println(" :g");
            }
            if (params.debugLvl > 0) {
                if (icall == 0) {
                    Util.printDbg("Number of training records " + numRecord);
                }
                if (grad != null) Util.printDbg("Iter " + icall + " loglikelihood "+logli + " gnorm " + norm(grad) + " xnorm "+ norm(lambda));
            }
            return logli;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    double Z=0;
    public double GetZ()
    {
    	    Integer  key1;
    	     Z =0;
    	     for (Enumeration e1 = alpha_Inside[0][alpha_Inside[0].length-1].keys(); e1
								.hasMoreElements();)
    	     {
    	    	 key1 = (Integer) e1.nextElement();
    	    	  if(key1!=null&&beta_Outside[0][beta_Outside[0].length-1].get(key1)!=null)
    	    	  {
    	                  Z=Z+ alpha_Inside[0][alpha_Inside[0].length-1].get(key1);    	    		  
    	    	  }
    	     }
    	     return Z;
    	
    }
    
    public double  GetMiu(DataSequence dataSeq,int i,int j ,int k,int head ,int body0,int body1)
    {
    	Double Valuebeta;
    	Double Valuealpha1;
    	Double Valuealpha2;
    	Double Valuerule;
    	if(beta_Outside[i][j]!=null&&alpha_Inside[i][k]!=null&&alpha_Inside[k+1][j]!=null)
    	{
    	Valuebeta = beta_Outside[i][j].get(head);
    	Valuealpha1 = alpha_Inside[i][k].get(body0);
    	Valuealpha2 = alpha_Inside[k+1][j].get(body1);
	
    	
		if(Valuebeta!=null&&Valuealpha1!=null&&Valuealpha2!=null)
		{	
			
			Valuerule = expE(lambda[featureGen.rulemaplambda(dataSeq,i,j,k,head,body0,body1)]);
			return (Valuebeta*Valuerule)*(Valuealpha2*Valuealpha1);
			
		}else
		{
    	return 0.0; 
		}
    	}else
    	{
    		return 0.0;
    	}
    }
    
    public double  GetMiu(int i,int j ,int head)
    {
    	
    	
    	if(alpha_Inside[i][j]!=null&&beta_Outside[i][j]!=null)
    	{
    		Double value1;
    		Double value2;
    	     if((value1=alpha_Inside[i][j].get(head))!=null&&(value2=beta_Outside[i][j].get(head))!=null)
    	     {
    	    	 
    	    	 return value1*value2;
    	    	 
    	     }
    	     else
    	     {
    	    	 
    	    	 return 0.0;
    	     }
    		
    		
    	}else
    	{
    	    return 0.0;  
    	}
    }
    
    
    
    
    
    protected double sumProduct(DataSequence dataSeq, FeatureGenerator featureGenerator, 
            double lambda[], double grad[], double expFVals[], boolean onlyForwardPass, int numRecord, 
            FeatureGenerator fgenForExpVals) {
    	
    	
    	
    	InsideOutside(dataSeq);
    	
    	
    	
    	 GetZ();
    	 Integer key1;
    	 Integer key2;  
    	 Integer  head;
    	 Long key;
    	 Hashtable<Integer,Integer>temp;
    	 double thisSeqLogli = 0;
    	 
    	 for(int i=0;i<alpha_Inside.length;i++)
    	 {
    	    	if(alpha_Inside[i][i]!=null&&beta_Outside[i][i]!=null)
    	    	{
    	    		 for (Enumeration e1 = alpha_Inside[i][i].keys(); e1
      				.hasMoreElements();)
     				 {   
     					 key1 = (Integer) e1.nextElement();
     					 for (Enumeration e2 = beta_Outside[i][i].keys(); e2
     	     				.hasMoreElements();)
     					 {
     						 key2 = (Integer) e2.nextElement();
     						 
     						 if(key1==key2)
     						 {
     							 temp =featureGen.lexicalrulemaplambda((DCTrainRecord)dataSeq,i);  
                                 int lamdaId = temp.get(key2);
                                 grad[lamdaId] =grad[lamdaId] -(alpha_Inside[i][i].get(key2)*beta_Outside[i][i].get(key2))/Z;
     						
     						 
     						 }
     						 		 
     					 }
     				 }
    	    		
    	    	}
    		 
    		 }
    	 
    	 for(int i=0;i<alpha_Inside.length;i++)
    		 {
				    		   for(int j =0;j<alpha_Inside.length;j++)
				    		 {
				    			 
							    			 for(int k=i;k<j;k++)
							    			 {				 
							    				 if(alpha_Inside[i][k]!=null&&alpha_Inside[k+1][j]!=null&&beta_Outside[i][j]!=null)
							    				   {
							    					   
							    					 for (Enumeration e1 = alpha_Inside[i][k].keys(); e1
							    	     				.hasMoreElements();)
							    	    				 {   
							    	    					     key1 = (Integer) e1.nextElement();
							    	    					 for (Enumeration e2 = alpha_Inside[k+1][j].keys(); e2
							    	    	     				.hasMoreElements();)
							    	    					 {
							    	    						 key2 = (Integer) e2.nextElement();	
							    	    						 key =  featureGen.grammerMapsGetKey(key1, key2,
							    											0);
							    	    						 
							    	    						
							    	    								 LinkedList list = featureGen.grammerMaps
							    											.get(new Long(key));
							    	    								     if(list==null)
							    	    								     {
							    	    								    	 continue;
							    	    								     }
							    	    								 
							    	    								 ListIterator<Integer> E = list.listIterator();
							    	    								 	while (E.hasNext()) {
							    	    								 		  
							    	    								 		  Double outsidevalue;
							    	    								 		  head = E.next();
							    	    								 		  
							    	    								 		  if((outsidevalue = beta_Outside[i][j].get(head))!=null)
							    	    								 		  {
							    	    								 			 int lambdaId = featureGen.rulemaplambda(dataSeq,i,j,k,head,key1,key2);
							    	    								 			 grad[lambdaId] = grad[lambdaId]- ((expE(lambda[lambdaId])*outsidevalue)*(alpha_Inside[i][k].get(key1)*alpha_Inside[k+1][j].get(key2)))/Z; 
							    	    								 			  
							    	    								 		  }
							    	    								 		  
							    	    								 	}
							    	    						 
							    					 
							    					 
							    	    					 }
							    	    					 }
							    				   }
							    			 
							    			 
							    			 
							    			 }
				    			 
				    		 }
    		   }
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 /*test-begin*/
    	/*
    	 for(int i=0;i<alpha_Inside.length;i++)
    		 for(int j =0;j<alpha_Inside.length;j++)
    		 {
    			 
    			 for(int k=i;k<j;k++)
    			 {				 
    				 
    				   if(alpha_Inside[i][k]==null||alpha_Inside[k+1][j]==null)
    				   {
    					   
    					   continue;
    					   
    				   }
    				 for (Enumeration e1 = alpha_Inside[i][k].keys(); e1
     				.hasMoreElements();)
    				 {   
    					 key1 = (Integer) e1.nextElement();
    					 for (Enumeration e2 = alpha_Inside[k+1][j].keys(); e2
    	     				.hasMoreElements();)
    					 {
    						             key2 = (Integer) e2.nextElement();	
    						 
    						           key =  featureGen.grammerMapsGetKey(key1, key2,
										0);
								          LinkedList list = featureGen.grammerMaps
										.get(new Long(key));
								             if (list == null) {
									                      continue;

								                  }
								            ListIterator<Integer> E = list.listIterator();
							      	while (E.hasNext()) {
    						             
									                    head = E.next();
									               double bug = GetMiu(dataSeq,i,j,k,head,key1,key2);
									                 if(GetMiu(dataSeq,i,j,k,head,key1,key2)>Z)
									                  {
										 
										                      System.out.println(GetMiu(dataSeq,i,j,k,head,key1,key2)/Z);
										                      
										                      GetMiu(dataSeq,i,j,k,head,key1,key2);
									                         }
									                
										                    ;
    						 	 
    					                                    }
    					 
    				   }
    			 }
    			 
    			 
    			 }
    		 }*/
    	 /*end*/
    	         /* computer numerator
    	          * 
      	          */
    	 
    	                 DCTrainRecord DataSeq  = (DCTrainRecord)dataSeq;
    	                      for(int i=0;i<DataSeq.ls.length-1;i++)
    	                      {
    	                    	  if(DataSeq.ls[i].length==3)
    	                    	  {
    	                    		  int head1  =   DataSeq.ls[i][0];
    	                      	      int body0 =    DataSeq.ls[DataSeq.ls[i][1]][0];
    	                      	      int body1 =    DataSeq.ls[DataSeq.ls[i][2]][0];
    	                      	      int lambdaId = featureGen.rulemaplambda(dataSeq,i,head1,body0,body1);
    	                      	     
    	                      	      grad[lambdaId] =  grad[lambdaId]+1;
    	                      	      thisSeqLogli = thisSeqLogli+lambda[lambdaId];
    	                    	  }
    	                    	  if(DataSeq.ls[i].length==2&&DataSeq.ls[i][1]>>Short.SIZE!=0)
    	                    	  {
    	                    		
    	                    		  int lambdaId = featureGen.lexicalrulemaplambda1(DataSeq,i);
    	                    		  
    	                    		  grad[lambdaId] = grad[lambdaId]+1;
    	                    		  thisSeqLogli = thisSeqLogli+ lambda[lambdaId];
    	                    	  
    	                    	  
    	                    	  }
    	                    	  
    	                      }
    	return thisSeqLogli - log(Z);
    }
    static double log(double val) {
        try {
            return logE(val);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return -1*Double.MAX_VALUE;
    }
    
    static double logE(double val) throws Exception {
        double pr = Math.log(val);
        if (Double.isNaN(pr) || Double.isInfinite(pr)) {
            throw new Exception("Overflow error when taking log of " + val);
        }
        return pr;
    } 
    static double expE(double val)  {
        double pr = RobustMath.exp(val);
        if (Double.isNaN(pr) || Double.isInfinite(pr)) {   	
            try {
                throw new Exception("Overflow error when taking exp of " + val + "\n Try running the CRF with the following option \"trainer ll\" to perform computations in the log-space.");
            } catch (Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
                return Double.MAX_VALUE;
            }
        }
        return pr;
    }
    static double expLE(double val) {
        double pr = RobustMath.exp(val);
        if (Double.isNaN(pr) || Double.isInfinite(pr)) {
            try {
                throw new Exception("Overflow error when taking exp of " + val 
                        + " you might need to redesign feature values so as to not reach such high values");
            } catch (Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
                return Double.MAX_VALUE;
            }
        }
        return pr;
    }
	protected void doTrain() {
		// TODO Auto-generated method stub
		return;
	}
}
