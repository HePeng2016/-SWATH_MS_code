/** WordsInTrain.java
 * 
 * @author Sunita Sarawagi
 * @version 1.3
 */
package iitb.Model;
import java.util.*;
import java.io.*;
import iitb.CRF.*;
import iitb.Tagging.DCTrainRecord;
import iitb.Tagging.DataCruncher;
/**
 *
 * This is created by FeatureGenTypes and is available for any
 * featureTypes class to use. What it does is provide you counts of
 * the number of times a word occurs in a state.
 * 
 * @author Sunita Sarawagi
 * */


public class TagWordsInTrain implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 4743850971317817295L;
	public static Hashtable<Integer,String> namelabelmap;
	public class HEntry implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 7173469259440218615L;
		int index;
        int cnt;
        Hashtable<Integer,Integer> tokenArray;
        HEntry() {
        	tokenArray = new Hashtable<Integer,Integer>();
        }
        void put(int t)
        {
        	Integer value;
        	if((value=tokenArray.get(t))==null)
        	{
        		tokenArray.put(t,0);
        		
        	}else
        	{
        		tokenArray.put(t,value.intValue()+1);
        	}	
        }
    };
    //TODO: Might be improved by generics.
    class Dictionary extends Hashtable<String,HEntry> {
        /**
		 * 
		 */
		private static final long serialVersionUID = -6961655882827666386L;
		@Override
        public synchronized boolean containsKey(Object key) {
            return super.containsKey(getKey(key));
        }
        @Override
        public synchronized HEntry get(Object key) {
            return super.get(getKey(key));
        }

        @Override
        public synchronized HEntry put(String key, HEntry value) {
            return super.put(key, value);
        }
        public Object getKey(Object w) {
            return tokenGenerator.getKey(w);
        }
    }
    public  Dictionary dictionary;
    private int cntsArray[][];
    private int cntsOverAllWords[];
    private int allTotal;

    TokenGenerator tokenGenerator;
    public TagWordsInTrain() {
        this(new TokenGenerator());
    }
    public TagWordsInTrain(TokenGenerator tokenGen) {
        tokenGenerator = tokenGen;
        dictionary = new Dictionary(); 
    }
    public Object getKey(Object w) {
        return tokenGenerator.getKey(w);
    }
    int[] getStateArray(int pos) {
        return cntsArray[pos];
    }
    public int getIndex(Object w) {
        return ((dictionary.get(w))).index;
    }
   
    public int DictionarySize()
    {
      return dictionary.size();
    }
    boolean inDictionary(Object w) {
        return (dictionary.get(w) != null);
    }
    public int count(Object w) {
        HEntry entry = dictionary.get(w);
        return ((entry != null)?entry.cnt:0);
    }
    public int count(int wordPos, int state) {
        return getStateArray(wordPos)[state];
    }
    public int count(int state) {
        return cntsOverAllWords[state];
    }
    public int totalCount() {return allTotal;}

    public int dictionaryLength() {return dictionary.size();}

    public int nextStateWithWord(Object w, int prev) {
        if (!inDictionary(w))
            return -1;
        int pos = getIndex(w);
        return nextStateWithWord(pos,prev);
    }
    public int nextStateWithWord(int pos, int prev) {
        int k = 0;
        if (prev >= 0)
            k = prev + 1;
        for (; k < getStateArray(pos).length; k++) {
            if (getStateArray(pos)[k] > 0)
                return k;
        }
        return -1;
    }
    public Enumeration allWords() {return dictionary.keys();}
    private void addDictElem(String x, int y) {
        HEntry index = dictionary.get(x);
        if (index == null) {
            index = new HEntry();
            index.put(y);
            index.index = dictionary.size();
            dictionary.put(x, index);
        }else
        {
           index.cnt++;
           index.put(y);
        }
    }
    protected void addDictElem(String x, int y, int nelems) {
        HEntry index = dictionary.get(x);
        if (index == null) {
            index = new HEntry();
            index.put(y);
            index.index = dictionary.size();
            dictionary.put(x, index);
        }
        index.cnt++;
        index.put(y);
    }
    void setAggregateCnts(int numStates) {
        cntsOverAllWords = new int[numStates];
        for (int i = 0; i < numStates; i++) {
            cntsOverAllWords[i] = 0;
            for (int m = 0; m < cntsArray.length; m++)
                cntsOverAllWords[i] += getStateArray(m)[i];
            allTotal += cntsOverAllWords[i];
        }
    }
    protected void postProcess(int numStates){
        cntsArray = new int[dictionary.size()][0];
        for (Enumeration e = dictionary.keys() ; e.hasMoreElements() ;) {
            Object key = e.nextElement();
            HEntry entry = dictionary.get(key);
        //    cntsArray[entry.index] = entry.stateArray;
        }   
        setAggregateCnts(numStates);
    }
    public void train(DataIter trainData) {
    	
    	Short flag = new Short((short)0);
    	int shortsize =  flag.SIZE;
    	int filter =1;
    	filter = filter<<flag.SIZE;
    	filter = ~filter;
        for (trainData.startScan(); trainData.hasNext();) {
        	DCTrainRecord seq =(DCTrainRecord)trainData.next();
              for(int i =0;i<seq.ls.length;i++)
              {
            	   if(seq.ls[i].length==2&&seq.ls[i][1]>>shortsize!=0)
            	   {
            		    addDictElem(seq._tokens[(seq.ls[i][1]&filter)],seq.ls[i][0]);
            	   }
            	   
              }
                    
          
        }
    }
    
    
    public void read(BufferedReader in, int numStates) throws IOException {
        int dictLen = Integer.parseInt(in.readLine());
        cntsArray = new int[dictLen][numStates];
        String line;
        for(int l = 0; (l < dictLen) && ((line=in.readLine())!=null); l++)
        {
        	 String array[] = line.split(" ");
        	 int  len = Integer.parseInt(array[1]);
        	 HEntry hEntry = new HEntry();
        	 for(int j =0;j<len;j++)
        	 {
        		 line=in.readLine();
        		 hEntry.put(Integer.parseInt(line)); 
        	 }
        	 hEntry.index = Integer.parseInt(array[2]);
        	 dictionary.put(array[0],hEntry);
        	
        }
        
        /*
        for(int l = 0; (l < dictLen) && ((line=in.readLine())!=null); l++) {
            StringTokenizer entry = new StringTokenizer(line," ");
            String key = entry.nextToken();
            int pos = Integer.parseInt(entry.nextToken());
            HEntry hEntry = new HEntry();
            dictionary.put(key,hEntry);
            while (entry.hasMoreTokens()) {
                StringTokenizer scp = new StringTokenizer(entry.nextToken(),":");
                int state = Integer.parseInt(scp.nextToken());
                int cnt = Integer.parseInt(scp.nextToken());          
                getStateArray(pos)[state] = cnt;
                hEntry.cnt += cnt;
            }
        }
        setAggregateCnts(numStates);*/
    }
    public void write(PrintWriter out) throws IOException {
        out.println(dictionary.size());
        for (Enumeration e = dictionary.keys() ; e.hasMoreElements() ;) {
            
        	Object key = e.nextElement();
            HEntry entry = dictionary.get(key);
            out.println(key +" "+ entry.tokenArray.size()+" "+ entry.index);
            
            for (Enumeration e1 =  entry.tokenArray.keys(); e1.hasMoreElements(); )
            {
            	int key2 = (Integer) e1.nextElement();
                out.println(key2);
            }
        }	
    }
    /*
    public Collection<String> wordSet() {
        return  dictionary.keySet();
    }
    */
};
