/** FeatureGenImpl.java
 * 
 * @author Sunita Sarawagi
 * @since 1.0
 * @version 1.3
 */

package iitb.Model;
import gnu.trove.set.hash.TIntHashSet;
import iitb.CRF.DataIter;
import iitb.CRF.DataSequence;
import iitb.Model.TagWordsInTrain.HEntry;
import iitb.Tagging.DCTrainRecord;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.StringTokenizer;
import java.util.Vector;

/**
 * The FeatureGenerator is an aggregator over all these different
 * feature types. You can inherit from the FeatureGenImpl class and
 * after calling one of the constructors that does not make a call to
 * (addFeatures()) you can then implement your own addFeatures
 * class. There you will typically add the EdgeFeatures feature first
 * and then the rest.  So, for example if you wanted to add some
 * parameter for each label (like a prior), you can create a new
 * FeatureTypes class that will create as many featureids as the
 * number of labels. You will have to create a new class that is
 * derived from FeatureGenImpl and just have a different
 * implementation of the addFeatures subroutine. The rest will be
 * handled by the parent class.  
 * This class  is responsible for converting the
 * string-ids that the FeatureTypes assign to their features into
 * distinct numbers. It has a inner class called FeatureMap that will
 * make one pass over the training data and create the map of
 * featurenames->integer id and as a side effect count the number of
 * features.
 *
 * @author Sunita Sarawagi
 * */

public class FeatureGenImpl{
    /**
	 * 
	 */
	private static final long serialVersionUID = 7651911985442866611L;
	
    int numFeatureTypes=0;
    int totalFeatures;
    boolean _fixedTransitions=true;
    public boolean generateOnlyXFeatures=false;
    public boolean addOnlyTrainFeatures=true;
    public Hashtable<Integer,Double> root = new Hashtable<Integer,Double>();
    public Hashtable<Integer,String> namelabelmap;
    TIntHashSet retainedFeatureTypes=new TIntHashSet(); // all features of this type are retained.
    public Hashtable<Long,LinkedList> grammerMaps = new Hashtable<Long,LinkedList>();
                                                // #body0 body1 ->head    0 
                                                // #head  body0 ->body1   1 
                                                // #head  body1 ->body0   2 
                                                // nonterminal alphabet
    public long grammerMapsGetKey(int entry1,int entry2,int flag)
    {
    	   long key = 0;   
    	    key = key|flag;
    	    key = key<<(Long.SIZE-4);
    	    key = key + entry1*tokenSize + entry2;
    	    return key;
    }

    public Hashtable<Long,Hashtable<Short, Double>> grammerRoots;// terminal alphabet -> nonterminal alphabets//���ڴʻ�Ĳ�ʹ��

    public Hashtable<Long,Integer> grammermapLambda = new Hashtable<Long,Integer>(); //rule->lambda
    transient DataSequence data;
    int cposEnd;
    int cposStart;
    public TagWordsInTrain dict;
    Vector<TagWordsInTrain> otherDicts = new Vector<TagWordsInTrain>();
    
    public void setDict(TagWordsInTrain d) {
        dict = d;
    }
    public TagWordsInTrain getDict(){
        if (dict == null)
            dict = new TagWordsInTrain();
        return dict;
    }
   
 

  
    protected boolean featureCollectMode = false;
    class FeatureMap implements Serializable {
        /**
		 * 
		 */
		private static final long serialVersionUID = -2268366275560581428L;
        FeatureMap(){
            featureCollectMode = true;
        }
       
        public int read(BufferedReader in) throws IOException {
          
        	/*in.readLine();
            int len = Integer.parseInt(in.readLine());
            String line;
            for(int l = 0; (l < len) && ((line=in.readLine())!=null); l++) {
                StringTokenizer entry = new StringTokenizer(line," ");
                FeatureIdentifier key = new FeatureIdentifier(entry.nextToken());
                int pos = Integer.parseInt(entry.nextToken());
                strToInt.put(key,new FeatureImpl(pos,key));
            }
            return strToInt.size();*/
        	return 0; //todo
        }
     
    };
    FeatureMap featureMap;
  
   
    public FeatureGenImpl() throws Exception {
   
        featureMap = new FeatureMap();
        dict = new TagWordsInTrain();
        
    }
    

 
 
    public int maxMemory() {return 1;}
    public boolean train(DataIter trainData) throws Exception {
        return train(trainData,true);
    }
    public boolean train(DataIter trainData, boolean cachedLabels) throws Exception {
        return train(trainData,cachedLabels,true);
    }

    public boolean containvalue(Integer value, LinkedList list)
    {
    	
    	
    	ListIterator<Integer> E  = list.listIterator();
    	while(E.hasNext())
    	{
    		Integer value1 = E.next();
    		if(value1.intValue()==value.intValue())
    		{
    			return true;
    		}
    		
    	}
    	return false;
    }
    int filter =1;
   
    public  void FeatureGenerate(DCTrainRecord seq){
    	
    	
    	filter = filter<<Short.SIZE;
    	filter = ~filter;
    	long key =0;
    	
    	 for(int i =0;i<seq.ls.length;i++){
    		 if(seq.ls[i].length==2&&seq.ls[i][1]>>Short.SIZE!=0)
    		 {
    			 key =0;
    			 key = key|1;//#1 lexical rule feature 
    			 key = key<<Long.SIZE-1;
    			 key = key + (long)dict.dictionary.get(seq._tokens[seq.ls[i][1]&filter]).index*(long)tokenSize;
    			 key = key +seq.ls[i][0];
    			 if(grammermapLambda.get(key)==null)
    			 {
    				 
    			       grammermapLambda.put(key, grammermapLambda.size());
    			       
    			 }
    			 
    			 //��򵥵�ʵ�ֲ�����������
    			 //to do 
    		 }
    		 if(seq.ls[i].length==3)
    		 {
    			   int  head =   seq.ls[i][0];
         	       int  body0 =  seq.ls[seq.ls[i][1]][0];
         	       int  body1 =  seq.ls[seq.ls[i][2]][0];
    			  
         	      key =0;
     			  key = key + (long)head*(long)tokenSize*(long)tokenSize+(long)tokenSize*(long)body0+(long)body1;
     			 if(grammermapLambda.get(key)==null)
    			 {
    				 
    			       grammermapLambda.put(key, grammermapLambda.size());
    			       
    			 }
     			  //��򵥵�ʵ�ֲ��������´ʻ�.
     			  // to to 
    		 }
    		 
         }
  
    	
    }
    public int tokenSize = 0;
    
    public int WordSize = 0;
  
    public boolean train(DataIter trainData, boolean cachedLabels, boolean collectIds) throws Exception {
        // map the y-values in the training set.
        boolean labelsMapped = false;
      
        if (dict != null) dict.train(trainData);
          dict.namelabelmap = this.namelabelmap;
         // int size = Short.SIZE;
          WordSize =dict.DictionarySize();
          
          for (trainData.startScan(); trainData.hasNext();) {
          	DCTrainRecord seq =(DCTrainRecord)trainData.next();
                for(int i =0;i<seq.ls.length;i++)
                {
              	   if(seq.ls[i].length==3)
              	   {
              	      int head  =    seq.ls[i][0];
              	      int body0 =    seq.ls[seq.ls[i][1]][0];
              	      int body1 =    seq.ls[seq.ls[i][2]][0];
              	      long rule;
              	      
              	      
              	      LinkedList list;
              	      rule = grammerMapsGetKey(body0,body1,0);
              	    if((list = this.grammerMaps.get(rule))==null)
              	       {
              	    	   list = new LinkedList();
              	    	   list.add(head);
              	           this.grammerMaps.put(rule,list);
              	       }
              	    else
              	    {
              	    	if(!containvalue(head,list))
          	    	   {
          	    		   list.add(head);
          	    	   }   
              	    	
              	    }
              	    
            	      rule = grammerMapsGetKey(head,body0,1);
            	      if((list = this.grammerMaps.get(rule))==null)
             	       {
             	    	   list = new LinkedList();
             	    	   list.add(body1);
             	           this.grammerMaps.put(rule,list);
             	       }else
             	       {
             	    	   if(!containvalue(body1,list))
             	    	   {
             	    		   list.add(body1);
             	    	   }     
             	       }

            	      
            	      rule = grammerMapsGetKey(head,body1,2);
            	      if((list = this.grammerMaps.get(rule))==null)
            	       {
            	    	   list = new LinkedList();
            	    	   list.add(body0);
            	           this.grammerMaps.put(rule,list);
            	       }else
            	       {
            	    	   if(!containvalue(body0,list))
            	    	   {
            	    		   list.add(body0);
            	    	   }     
            	       }         	       
              	   }
                }  
                if(root.get(seq.ls[seq.ls.length-1][0])==null)
                {
              	    root.put(seq.ls[seq.ls.length-1][0], 1.0);
                }  
          }  
          for (trainData.startScan(); trainData.hasNext();) {
        	  
            	DCTrainRecord seq =(DCTrainRecord)trainData.next();
            	FeatureGenerate(seq);
          }
            return true;
    };
   
    public  int rulemaplambda(DataSequence d,int i,int j ,int m,int head,int body0,int body1)
    {
    	     
    	  return grammermapLambda.get((long)head*(long)tokenSize*(long)tokenSize+(long)tokenSize*(long)body0+(long)body1);
    	// �� FeatureGenerate �Ĵ����Ӧ
    }
    public  int rulemaplambda(DataSequence d,int i,int head,int body0,int body1)
    {
    	     
    	  return grammermapLambda.get((long)head*(long)tokenSize*(long)tokenSize+(long)tokenSize*(long)body0+(long)body1);
    	// �� FeatureGenerate �Ĵ����Ӧ
    }
    public int lexicalrulemaplambda1( DCTrainRecord seq,int i )
    {
    	 long key =0;
		 key = key|1;//#1 lexical rule feature 
		 key = key<<Long.SIZE-1;
		 key = key + (long)dict.dictionary.get(seq._tokens[seq.ls[i][1]&filter]).index*(long)tokenSize;
		 key = key +seq.ls[i][0];
		 Integer Value;
		 
		 if( (Value = grammermapLambda.get(key))!= null)
		 {
			 return Value;
			 
		 }else
		 {
			 return -1;
			 
		 }
    	 
    	
    	//�� FeatureGenerate �Ĵ����Ӧ
    }
    
    
    public Hashtable<Integer,Integer> lexicalrulemaplambda(DCTrainRecord  d,int i)
    {
    	HEntry key =  dict.dictionary.get(d._tokens[i]);
    	
    	Hashtable<Integer,Integer> result = new Hashtable<Integer,Integer>();
    	  if(key==null)
    	  {
    		  return result;
    		  //to do δ��¼�ʴ���
    	  }
    	 long key1 =0;
			  key1 = key1|1;//#1 lexical rule feature 
			  key1 = key1<<Long.SIZE-1;
			  key1 = key1 + key.index*tokenSize;
    
    	  for (Enumeration e = key.tokenArray.keys() ; e.hasMoreElements() ;) {
    		  
    		  Integer  entrykey =(Integer)e.nextElement();
    		  Integer  lambdaId =  grammermapLambda.get(entrykey.intValue()+key1);  
    		  if(lambdaId!=null)
    		  result.put(entrykey.intValue(),lambdaId.intValue());
          }

    	// �� FeatureGenerate �Ĵ����Ӧ
      return result;	
    }
    
    


  

  
    public int numFeatures() {
        return grammermapLambda.size();
    }
  

    public void read(String fileName) throws IOException {
        BufferedReader in=new BufferedReader(new FileReader(fileName));
        if (dict != null) dict.read(in, 0);
        WordSize = dict.dictionary.size();
    }
    
    public void featureread(String fileName)throws IOException 
    { 
    	BufferedReader in=new BufferedReader(new FileReader(fileName));
    	tokenSize = Integer.parseInt(in.readLine());
    	int rootLen = Integer.parseInt(in.readLine());
    	String  line;
    	  for(int l = 0; (l < rootLen) && ((line=in.readLine())!=null); l++)
    	  {
    		  String array[] = line.split(" ");
    		  root.put(Integer.valueOf(array[0]),Double.valueOf(array[1]));
    	  }
    		int MapLen = Integer.parseInt(in.readLine());
    		 for(int l = 0; (l < MapLen) && ((line=in.readLine())!=null); l++)
       	  {
       		    String array[] = line.split(" ");
       		    long key = Long.parseLong(array[0]);
       		    LinkedList list = new LinkedList();
       		    for(int i=1;i<array.length;i++)
       		       list.add(Integer.parseInt(array[i]));  
       		     grammerMaps.put(key,list);
       	  }
    		 int MapRuleLen = Integer.parseInt(in.readLine());
    		 for(int l = 0; (l < MapRuleLen) && ((line=in.readLine())!=null); l++)
    		 {
    			  
    			  String array[] = line.split(" ");	 
    			  grammermapLambda.put(Long.parseLong(array[0]),Integer.parseInt(array[1]));
    			 
    		 }
    		 
    		 
    }
    
    
    public void write(String fileName) throws IOException {
        PrintWriter out=new PrintWriter(new FileOutputStream(fileName));
        if (dict != null) dict.write(out);
     //   featureMap.write(out);
        out.close();
    }
   public void featurewrite(String fileName) throws IOException
   {
	   PrintWriter out = new PrintWriter(new FileOutputStream(fileName));
	   out.println(tokenSize);
	   out.println(root.size());
       for (Enumeration e = root.keys() ; e.hasMoreElements() ;) {
            
    	     Object key = e.nextElement();
            
    	     out.println(key+" "+root.get(key));
       }
       out.println(grammerMaps.size());
       for (Enumeration e =grammerMaps.keys() ; e.hasMoreElements() ;) {
            
    	     Object key = e.nextElement();
    	     out.print(key);
    	     LinkedList  key2 = grammerMaps.get(key);
    	     
    	     ListIterator<Integer>Itetator = key2.listIterator();
    	      
    	     while(Itetator.hasNext())
    	     {
    	         out.print(" "+(Itetator.next()));
    	     }
    	     out.print("\n");
        
       }
       out.println(grammermapLambda.size());
       for (Enumeration e =grammermapLambda.keys() ; e.hasMoreElements() ;) {
           
  	        Object key = e.nextElement();
  	        
  	        out.println(key+" "+grammermapLambda.get(key));
     }
       
	   
	   out.close();
   }

 
        /*
         out.println("Feature types statistics");
         for (int f = 0; f < features.size(); f++) {
         getFeature(f).print(featureMap, featureWts);
         }
         */
    
    
    public boolean fixedTransitionFeatures() {
        return _fixedTransitions;
    }
    // returns the label-independent featureId of the current feature
   
    public void addDict(TagWordsInTrain ngramDict) {
        otherDicts.add(ngramDict);
    }
};
