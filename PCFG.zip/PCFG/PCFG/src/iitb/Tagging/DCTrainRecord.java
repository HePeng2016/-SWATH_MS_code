package iitb.Tagging;
import iitb.CRF.DataSequence;
import iitb.CRF.Segmentation;
import iitb.Model.TagWordsInTrain.HEntry;
import iitb.Tagging.Tagging.TestRecord;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Pattern;

public  class DCTrainRecord  implements TrainRecord{

	private static final long serialVersionUID = -3412644222368304767L;
	public int[][] ls;
    public String[]_tokens;

    int[] labelsPerToken;
    int[] snum, spos;
    Hashtable<Object,String> labelmap;
    DCTrainRecord(int[][] ts, String[]toks) {
        ls = ts;
        _tokens = toks;
      
    }
    DCTrainRecord()
    {
    	 ls = null;
    	 _tokens = null;
    	
    }
    
    public int[] labels() {
        return ls[0];
    }
    public void set_y(int i, int l) {labelsPerToken[i] = l;} // not applicable for training data.
    public int length() {return _tokens.length;}
    public Object x(int i) {return _tokens[i];}
    public int y(int i) {return  labelsPerToken[i];}

    public int numSegments() {
        return ls.length;
    }
    public int numSegments(int l) {
        int sz = 0;
        return sz;
    }
    public String[] tokens(int snum) {
        return _tokens;
    }
    public String[] tokens(int l, int p) {
       
        return null;
    }
    /* (non-Javadoc)
     * @see iitb.CRF.SegmentDataSequence#getSegmentEnd(int)
     */
    public int getSegmentEnd(int segmentStart) {
        for (int i = segmentStart+1; i < length(); i++) {
            if (y(i)!= y(segmentStart))
                return i-1;
        }
        return length()-1;
    }
    /* (non-Javadoc)
     * @see iitb.CRF.SegmentDataSequence#setSegment(int, int, int)
     */
	public void setSegment(int segmentStart, int segmentEnd, int y) {
		// TODO Auto-generated method stub
		
	}
  
};