/** DataCruncher.java
 *
 * @author Sunita Sarawagi
 * @since 1.0
 * @version 1.3
 */ 
package iitb.Tagging;
import iitb.CRF.DataSequence;
import iitb.CRF.Segmentation;
import iitb.Model.TagWordsInTrain.HEntry;

import iitb.Tagging.Tagging.TestRecord;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Vector;
import java.util.regex.Pattern;

class DCTrainData implements TrainData {
    ArrayList<DCTrainRecord> trainRecs;
    int pos;
    DCTrainData(ArrayList<DCTrainRecord> trs) {
        trainRecs = trs;
    }
    public int size() {
        return trainRecs.size();
    }
    public void startScan() {
        pos = 0;
    }
    public TrainRecord nextRecord() {
    	
    	DCTrainRecord object;
    	object = trainRecs.get(pos++);
    	
        return (TrainRecord)object;
    }
    public boolean hasMoreRecords() {
        return (pos < size());
    }
    public boolean hasNext() {
        return hasMoreRecords();
    }
    public DataSequence next() {
        return nextRecord();
    }
    
    
};


class TestData {
    BufferedReader rin;
    String line;
    String seq[];
    String fname;
    String delimit, impDelimit;
	Hashtable<Long,String> inverseLabelmap = new Hashtable();
	Hashtable<Integer,Integer> inversecompactmap = new Hashtable(); 
    TestData(String file,String delimitP,String impDelimitP, String grpDelimit) {
        try {
            fname = file;
            rin =new BufferedReader(new FileReader(file+".raw"));
            delimit = delimitP;
            impDelimit = impDelimitP;
        }  catch(IOException e) {
            System.out.println("I/O Error"+e);
            System.exit(-1);
        }
        
  
    }
    
    void ReadMap(String file) throws IOException
    {
    	BufferedReader buf =new BufferedReader(new FileReader(file));
    	
    	String line;
    	line = buf.readLine();
    	int   inverseLabelmapsize =  Integer.parseInt(line);
    	for(int i =0;i<inverseLabelmapsize;i++)
    	{
    		line = buf.readLine();
    		String array[];
    		array = line.split(" ");
    		inverseLabelmap.put(Long.parseLong(array[0]),array[1]);
    	}
    	line = buf.readLine();
    	int  inversecompactmapsize = Integer.parseInt(line);
    	
    	for(int i =0;i<inversecompactmapsize;i++)
    	{
    		line = buf.readLine();
    		String array[];
    		array = line.split(" ");
    		inversecompactmap.put(Integer.parseInt(array[0]), Integer.parseInt(array[1]));
    		
    	}
    		
    }
    void startScan() {
        try {
            rin =new BufferedReader(new FileReader(fname+".raw"));
        }  catch(IOException e) {
            System.out.println("I/O Error"+e);
            System.exit(-1);
        }   
    }
    int[] groupedTokens() {
        /*
	if (grp == null)
	    return null;
	return grp.groupingArray(seq.length);
         */
        return null;
    }
    String[] nextRecord() {
        try {
            if ((line=rin.readLine())!=null) {
               
            	
                return line.split(" ");
            } else {
                rin.close();
                return null;
            }
        } catch(IOException e) {
            System.out.println("I/O Error"+e);
            System.exit(-1);
        }
        return null;
    }
    int [][]stack  = new int [1024][2];
    int stackIndex = 0;
    /*
     * stack[1] : 
     * 			0 start scan
     *             1 left  scan
     *             2 right scan 
     *             3 dump left scan
     *             4 dump right scan
     * 
     */
  
      
    
    String gettoken(int id)
    {
    try{
   	   id = inversecompactmap.get(id);
   	    
   	    if(id>>Short.SIZE!=0)
   	   {
   		  return null; 
   	   }
   	    
   	    return inverseLabelmap.get((long)id);
    }catch(Exception e)
    {
    	
    	return null;
    }
    }/*�ͱ����Ӧ*/
   
   void writeRecord(DCTrainRecord dataSeq,PrintWriter tdw){
   	
       
   	  stack[0][0] = 0;
   	  stack[0][1] = 0;
   	  stackIndex = 1;
   	  while(stackIndex!=0)
   	  {
   		  if(stack[stackIndex-1][1] == 0)
   		  {
   			    String TokenName = gettoken( dataSeq.ls[stack[stackIndex-1][0]][0]);
   			    if(TokenName !=null)
   			    {
   			    	 if(dataSeq.ls[stack[stackIndex-1][0]].length==3)
   			    	 {
   			    		stack[stackIndex-1][1] = 1;
   			    		stack[stackIndex][1] = 0;
   			    		stack[stackIndex][0] = dataSeq.ls[stack[stackIndex-1][0]][1]; 
   			    		stackIndex = stackIndex +1;
   			    		tdw.print(" [ ");
   			    		tdw.print(TokenName);
   			    		 continue;
   			    	 }
   			    	  if(dataSeq.ls[stack[stackIndex-1][0]].length==2)
   			    	 {
   			    		 
   			    		tdw.print(" ");  
   			    		tdw.print(dataSeq._tokens[dataSeq.ls[stack[stackIndex-1][0]][1]]) ; 
   			    		tdw.print("/");
   			    		tdw.print(TokenName);
   			    		tdw.print(" "); 
   			    		stackIndex = stackIndex -1;
   			    		continue;
   			    		 
   			    	 }
   			    	 
   			    }else
   			    {
   			    	if(dataSeq.ls[stack[stackIndex-1][0]].length==3)
  			    	 {
  			    		stack[stackIndex-1][1] = 3;
  			    		stack[stackIndex][1] = 0;
  			    		stack[stackIndex][0] = dataSeq.ls[stack[stackIndex-1][0]][1]; 
  			    		stackIndex = stackIndex +1;
  			    		continue;
  			    	 }
  			    	  if(dataSeq.ls[stack[stackIndex-1][0]].length==2)
  			    	 {
  			    		 
  			    		tdw.print(" ");  
  			    		tdw.print(dataSeq._tokens[dataSeq.ls[stack[stackIndex-1][0]][1]]) ; 
  			    		tdw.print("/");
  			    		tdw.print(TokenName);
  			    		tdw.print(" "); 
  			    		stackIndex = stackIndex -1;
  			    		continue;
  			    	 }
   			    	
   			    	
   			    }
   			    continue;
   		  }	  
   		    if(stack[stackIndex-1][1] == 1)
   		    {
   		    	stack[stackIndex-1][1] = 2;
   		    	stack[stackIndex][1] = 0;
   		    	stack[stackIndex][0] = dataSeq.ls[stack[stackIndex-1][0]][2]; 
   		    	stackIndex = stackIndex +1;
   		    	continue;
   		    	
   		    }
   		      if(stack[stackIndex-1][1] == 2)
 		    {
   		    	stackIndex = stackIndex -1;
   		    	
   		    	tdw.print(" ] ");
   		    	
   		    	continue;
 		    }
   		    if(stack[stackIndex-1][1] == 3)
   		    {
   		    	stack[stackIndex-1][1] = 4;
   		    	stack[stackIndex][1] = 0;
   		    	stack[stackIndex][0] = dataSeq.ls[stack[stackIndex-1][0]][2]; 
   		    	stackIndex = stackIndex +1;
   		    	continue;
   		    	
   		    }
   		      if(stack[stackIndex-1][1] == 4)
 		    {
   		    	stackIndex = stackIndex -1;
   		    	continue;
 		    } 
   		        
   	  }
   	  
     	tdw.print("\n");
   }; 
   
};

class TestDataWrite {
    PrintWriter out;
    BufferedReader rin;
    String outputBuffer;
    String rawLine;
    String delimit, tagDelimit, impDelimit;
    LabelMap labelmap;
    TestDataWrite(String outfile,String rawfile,String delimitP,String tagDelimitP,String impDelimitP, LabelMap linfo) {
        try {
            labelmap = linfo;
            out=new PrintWriter(new FileOutputStream(outfile+".tagged"));
            rin=new BufferedReader(new FileReader(rawfile+".raw"));
            outputBuffer=new String();
            delimit = delimitP;
            tagDelimit = tagDelimitP;
            impDelimit = impDelimitP;
        } catch(IOException e) {
            System.err.println("I/O Error"+e);
            System.exit(-1);
        }
    }	
    
  
  
    
    
    
    
    void writeRecord(int[] tok, int tokLen) {
        try {
            rawLine=rin.readLine();
            StringTokenizer rawTok=new StringTokenizer(rawLine,delimit,true);
            String tokArr[]=new String[rawTok.countTokens()];
            for(int j=0 ; j<tokArr.length ; j++) {
                tokArr[j]=rawTok.nextToken();
            }
            int ptr=0;
            int t=tok[0];
            for(int j=0 ; j<=tokLen ; j++) {
                if ((j < tokLen) && (t==tok[j])) {
                    while(ptr<tokArr.length && delimit.indexOf(tokArr[ptr])!=-1 && impDelimit.indexOf(tokArr[ptr])==-1) {
                        outputBuffer=new String(outputBuffer+tokArr[ptr]);

                        ptr++;
                    }
                    if (ptr<tokArr.length) {
                        outputBuffer=new String(outputBuffer+tokArr[ptr]);
                        ptr++;
                    }
                    while(ptr<tokArr.length && delimit.indexOf(tokArr[ptr])!=-1 && impDelimit.indexOf(tokArr[ptr])==-1) {
                        outputBuffer=new String(outputBuffer+tokArr[ptr]);
                        ptr++;
                    }
                } else {

                    int revScanPtr=outputBuffer.length()-1;
                    int goBackPtr=0;
                    boolean foundOpenChar=false;
                    while((revScanPtr >= 0) && (outputBuffer.charAt(revScanPtr)==' ' 
                        || outputBuffer.charAt(revScanPtr)=='(' || outputBuffer.charAt(revScanPtr)=='{' || outputBuffer.charAt(revScanPtr)=='[')) {
                        char currChar=outputBuffer.charAt(revScanPtr);
                        if (impDelimit.indexOf(currChar)!=-1) {
                            break;
                        }
                        if (currChar=='{' || currChar=='[' || currChar=='(') {
                            foundOpenChar=true;
                        }
                        revScanPtr--;
                        goBackPtr++;
                    }
                    if (foundOpenChar) {
                        outputBuffer=outputBuffer.substring(0,revScanPtr+1);
                        ptr-=goBackPtr;
                    }

                    outputBuffer=new String(outputBuffer+tagDelimit+labelmap.revMap(t));
                    out.println(outputBuffer);
                    outputBuffer=new String();
                    //						out.println(tagDelimit+t);
                    //						System.out.println(tagDelimit+t);
                    if (j < tokLen) {
                        t=tok[j];
                        j--;
                    }
                }
            }
            out.println();
        }  catch(IOException e) {
            System.err.println("I/O Error"+e);
            System.exit(-1);
        }
    }
    
    void writeRecord(int[] tok, int tokLen,Hashtable<Integer,String> labelmaps) 
    {
        try {
            rawLine=rin.readLine();
            StringTokenizer rawTok=new StringTokenizer(rawLine,delimit,true);
            String tokArr[]=new String[rawTok.countTokens()];
            for(int j=0 ; j<tokArr.length ; j++) {
                tokArr[j]=rawTok.nextToken();
            }
            int ptr=0;
            
            for(int j=0 ; j<tokLen ; j++) {
            	  int t =0;
            	     t=tok[j];
            	 if ((j < tokLen)) {
                    while(ptr<tokArr.length && delimit.indexOf(tokArr[ptr])!=-1 && impDelimit.indexOf(tokArr[ptr])==-1) {
                        outputBuffer=new String(outputBuffer+tokArr[ptr]);

                        ptr++;
                    }
                    if (ptr<tokArr.length) {
                        outputBuffer=new String(outputBuffer+tokArr[ptr]);
                        ptr++;
                    }
                    while(ptr<tokArr.length && delimit.indexOf(tokArr[ptr])!=-1 && impDelimit.indexOf(tokArr[ptr])==-1) {
                        outputBuffer=new String(outputBuffer+tokArr[ptr]);
                        ptr++;
                    }
                    int revScanPtr=outputBuffer.length()-1;
                    int goBackPtr=0;
                    boolean foundOpenChar=false;
                    while((revScanPtr >= 0) && (outputBuffer.charAt(revScanPtr)==' ' 
                        || outputBuffer.charAt(revScanPtr)=='(' || outputBuffer.charAt(revScanPtr)=='{' || outputBuffer.charAt(revScanPtr)=='[')) {
                        char currChar=outputBuffer.charAt(revScanPtr);
                        if (impDelimit.indexOf(currChar)!=-1) {
                            break;
                        }
                        if (currChar=='{' || currChar=='[' || currChar=='(') {
                            foundOpenChar=true;
                        }
                        revScanPtr--;
                        goBackPtr++;
                    }
                    if (foundOpenChar) {
                        outputBuffer=outputBuffer.substring(0,revScanPtr+1);
                        ptr-=goBackPtr;
                    }
                    outputBuffer = outputBuffer.trim();
                    outputBuffer=new String(outputBuffer+' '+tagDelimit+labelmaps.get(t));
                    out.println(outputBuffer);
                    outputBuffer=new String();
                    //						out.println(tagDelimit+t);
                    //						System.out.println(tagDelimit+t);
                   
                }
            }
            out.println();
        }  catch(IOException e) {
            System.err.println("I/O Error"+e);
            System.exit(-1);
        }
    }
    
    void close() {
        try {
            rin.close();
            out.close();
        }  catch(IOException e) {
            System.err.println("I/O Error"+e);
            System.exit(-1);
        } 
    }
};
class IntComparator implements Comparator<int[]>{
	public int compare(int[] o1, int[] o2) {
		
		if(o1.length>o2.length)
		{	
			return 1;
			
		}
		if(o1.length<o2.length)
		{
			return -1;
			
		}
		if(o1.length==o2.length)
		{
			for(int i =0;i<o2.length;i++)
			{
			   if(o1[i]>o2[i])
			   {
				   return  1;
			   }
			   if(o1[i]<o2[i])
			   {
				   return -1;
			   }
				
			}
			return 0;
		}
		
		return 0;
	}
}

public class DataCruncher {

	/**
	 * 
	 * @param text 
	 * @param delimit A set of delimiters used by the Tokenizer.
	 * @param impDelimit Delimiters to be retained for tagging. 
	 * @return an Array of tokens.
	 */
	
	 static Hashtable<String,Long> labelmap = new Hashtable();
	 static Hashtable<Long,String> inverseLabelmap = new Hashtable();
	 static Hashtable<Integer,Integer> compactmap = new Hashtable(); 
	 static Hashtable<Integer,Integer> inversecompactmap = new Hashtable(); 
	 static TreeMap<int[],Integer>  LongRulemap = new TreeMap<int[],Integer> (new IntComparator());
	 
	protected static String[] getTokenList(String text, String delimit,
			String impDelimit) {
		text = text.toLowerCase();
		StringTokenizer textTok = new StringTokenizer(text, delimit, true);
		//This allocates space for all tokens and delimiters, 
		//but will make a second pass through the String unnecessary.
		ArrayList<String> tokenList = new ArrayList<String>(textTok.countTokens());
		
		while (textTok.hasMoreTokens()) {
			String tokStr = textTok.nextToken();
			if (!delimit.contains(tokStr) || impDelimit.contains(tokStr)) {
				tokenList.add(tokStr);
			}
		}
		//Finally, the storage is trimmed to the actual size.
		return tokenList.toArray(new String[tokenList.size()]);
	}
    
	/**
	 * Reads a block of text ended by a blank line or the end of the file.
	 * The block contains lines of tokens with a label.
	 * @param numLabels The maximal number of labels expected
	 * @param tin 
	 * @param tagDelimit Separator between tokens and tag number
	 * @param delimit Used to define token boundaries
	 * @param impDelimit Delimiters to be retained for tagging
	 * @param t Stores the labels
	 * @param cArray Stores the tokens
	 * @return number of lines read
	 * @throws IOException
	 */


    static int readRowFixedCol(int numLabels, BufferedReader tin, String tagDelimit, 
    		String delimit, String impDelimit, int[] t, String[][] cArray, int labels[])
    		throws IOException {
        String line=tin.readLine();
        if (line == null)
            return 0;
        StringTokenizer firstSplit=new StringTokenizer(line.toLowerCase(),tagDelimit,true);
        int ptr = 0;
        for (int i = 0; (i < labels.length) && firstSplit.hasMoreTokens(); i++) {
            int label = labels[i];
            String w = firstSplit.nextToken();
            if (tagDelimit.indexOf(w)!=-1) {
                continue;
            } else {
                if (firstSplit.hasMoreTokens())
                    // read past the delimiter.
                    firstSplit.nextToken();
            }
            if ((label > 0) && (label <= numLabels)) {
                t[ptr] = label;
                cArray[ptr++] = getTokenList(w,delimit,impDelimit);
            }
        }
        return ptr;
    }

    /**
     * Checks, if the data are available in fixed column format, or variable
     * column format.
     * @param numLabels The maximal number of labels expected
     * @param tin
     * @param tagDelimit A character as String that acts as a delimiter between tokens and label.
     * @return An array with labels if the data are in fixed column format, null otherwise.
     * @throws IOException
     */
    static String[][]tokengrammer  = new String[1024*4*4][];
    static int [][] tokengrammerLocation = new int[1024*4*4][];
    static String[][]lexcalgrammer = new String[1024*4*4*4][2];
    static int [] lexcalgrammerLocation = new int[1024*4*4*4]; 
    static int tokengrammerindex  = 0;
    static int lexcalgrammerindex = 0;
    static int sentenceindex = 0;
    
	protected static int [][] readGrammerInfo(int numLabels, String line,
			String tagDelimit) throws IOException {
		if (line == null) {
			throw new IOException("Header row not present in tagged file");
		}
		int Y[] = new int[10];
		String stack[];
		int []stacklocation = new int[2048];
		stack = new String[2048];
		 int stackindex = 0;
		 tokengrammerindex = 0;
		 lexcalgrammerindex = 0;
		//String regex =" |\\]|\";	
		 line =   line.replace("]"," ] ");
		 line =   line.replace("["," [ ");
		 line =   line.replace("/", " / ");
		 String array[] = line.split(" ");
		 
		 for(int i=0;i<array.length;i++)
		 {
			 if( !array[i].equals("]"))
			 {
				 if(!array[i].equals(""))
				 {
					
					 if(array[i].equals("/"))
					 {
						
						 stack[stackindex-1] = array[i+1];
						 Short flag = new Short((short)0);
					     //stackindex = stackindex+1;
						 tokengrammer[tokengrammerindex] = new String[2];
			             tokengrammerLocation[tokengrammerindex] = new int[2]; // #TokenID    # Location #Location..... 
			             stacklocation[stackindex-1] = tokengrammerindex;
			             tokengrammer[tokengrammerindex][0] = array[i+1];
			             tokengrammerLocation[tokengrammerindex][1] = 0;
			             tokengrammerLocation[tokengrammerindex][1] = tokengrammerLocation[tokengrammerindex][1]|(short)1;//#  lexcalgrammer
			             tokengrammerLocation[tokengrammerindex][1] = tokengrammerLocation[tokengrammerindex][1]<<flag.SIZE;
			             tokengrammerLocation[tokengrammerindex][1] = tokengrammerLocation[tokengrammerindex][1]|(short)lexcalgrammerindex;
			             tokengrammerindex = tokengrammerindex +1;
					     lexcalgrammer[lexcalgrammerindex][0] = array[i-1];
					     lexcalgrammer[lexcalgrammerindex][1] = array[i+1];
					     lexcalgrammerLocation[lexcalgrammerindex] = sentenceindex;
					     sentenceindex = sentenceindex+1;
					     lexcalgrammerindex = lexcalgrammerindex+1;
					     i = i+1;
						
					 }else
					  { 
						 stack[stackindex] = array[i];
					     stackindex = stackindex+1;
					  }
				 }
			 }else
			 {
				 int end = stackindex-1;
                 while(!stack[stackindex-1].equals("["))	
                {
                    	stackindex = stackindex -1; 	
                   } 
                 stack[stackindex-1] =  stack[stackindex];
                 stacklocation[stackindex-1] = tokengrammerindex;
                 tokengrammer[tokengrammerindex] = new String[end-stackindex+1];
                 tokengrammerLocation[tokengrammerindex] = new int[end-stackindex+1]; // #TokenID    # Location #Location..... 
                 for(int j =stackindex;j<=end;j++)
                 {
                			 
                	     tokengrammer[tokengrammerindex][j-stackindex] = stack[j];
                	 
                 }
                 for(int j =stackindex+1;j<=end;j++)
                 {
                			 
                	     tokengrammerLocation[tokengrammerindex][j-stackindex] = stacklocation[j];
                	 
                 }
                 tokengrammerindex = tokengrammerindex+1;
			 }
		 }
		 
		 
		 //(regex);
		 
		 // Removing Unit Productions
		
		  Short flag = new Short((short)0);
		 for(int i =0;i<tokengrammerindex;i++)
		 {  
			if( tokengrammerLocation[i].length == 2&&(tokengrammerLocation[i][1]>>flag.SIZE)==0)
			{
				int temp = tokengrammerLocation[i][1];
				while((tokengrammer[temp].length==2)&&(tokengrammerLocation[temp][1]>>flag.SIZE)==0)
				{
				    temp = tokengrammerLocation[temp][1];
				}
				  String entry[]  = new String[tokengrammer[temp].length];
				  
				  entry[0] = tokengrammer[i][0];
				
	                for(int j = 1;j<tokengrammer[temp].length;j++){
										  entry[j] = tokengrammer[temp][j];
									  }		
				
				  tokengrammer[i] = entry;
				  tokengrammerLocation[i] = tokengrammerLocation[temp];	  
			} 
		 }
		 // fill  back tokengrammerLocation
		 for(int i =0;i<tokengrammerindex;i++)
		 {
			 if(tokengrammer[i]!=null)
			 {
			 if(labelmap.get(tokengrammer[i][0])==null)
			 {
				 labelmap.put(tokengrammer[i][0],(long)labelmap.size());
				 inverseLabelmap.put((long)(labelmap.size()-1),tokengrammer[i][0]);
				 
			 }
			 long key = labelmap.get(tokengrammer[i][0]);
			 
			 tokengrammerLocation[i][0] = (short)key;
			 }
		 }
	 int root = tokengrammerLocation[tokengrammerindex-1][0];
		 //Removing Rules with Long Right-hand sides 
		 
		 for(int i =0;i<tokengrammerindex;i++)
		 {
			   if( tokengrammerLocation[i].length >3)
			   {
				   
				    int token =tokengrammerLocation[i][tokengrammerLocation[i].length-1];
				   
				    for(int j = tokengrammerLocation[i].length-2;j>1;j--)
				    {
				    	int   key = 0;
				    	int[] rule =  new int[tokengrammerLocation[i].length];
				    	key = key|(short)j;
				    	key = key<<flag.SIZE;
				    	Integer ruleID;
				    	rule[0] = tokengrammerLocation[i][0];
				    	for(int k = 1;k<tokengrammerLocation[i].length;k++)
				    	{
				    		 rule[k] = tokengrammerLocation[tokengrammerLocation[i][k]][0];
				    		
				    	}
				    	   
				             if((ruleID =LongRulemap.get(rule))==null)
				             {
				            	 LongRulemap.put(rule,LongRulemap.size());
				            	 ruleID = LongRulemap.size()-1;
				             }
				             
				             
				    	key = key|ruleID.intValue();	
				    	tokengrammerLocation[tokengrammerindex] = new int[3]; 
				    	tokengrammerLocation[tokengrammerindex][0] = key;
				    	tokengrammerLocation[tokengrammerindex][1] = tokengrammerLocation[i][j];
				    	tokengrammerLocation[tokengrammerindex][2] = token;
				    	token = tokengrammerindex;
				    	tokengrammerindex = tokengrammerindex+1;
				    }
				    int entry[] = new int[3];
				    entry[0] = tokengrammerLocation[i][0];
				    entry[1] = tokengrammerLocation[i][1];
				    entry[2] = tokengrammerindex-1;
				    tokengrammerLocation[i] = entry;
				   
			   }
			 
		 }
		 
		 int [][]result =new int[tokengrammerindex+1][];
		 
		 for(int i=0;i<result.length;i++)
		 {
			 result[i] = tokengrammerLocation[i];
		 }
		 result[tokengrammerindex] = new int[1];
		 result[tokengrammerindex][0] = root;
		 
		 for(int i=0;i<result.length;i++)
		 {   
			  Integer key;
			  if((key = compactmap.get(result[i][0]))==null)
			 {
				 
				  compactmap.put(result[i][0],compactmap.size());
				  inversecompactmap.put(compactmap.size()-1,result[i][0]);
				  result[i][0] = compactmap.size()-1;
				  
					  }
			  else
			  {
				  result[i][0] = key.intValue();
				  
			  }
			 
		 }
		 return result;
		
	}
	
	public static TrainData readTagged(int numLabels, String tfile,
			String rfile, String delimit, String tagDelimit, String impDelimit,
			LabelMap labelMap) {
		try {
			ArrayList<DCTrainRecord> td = new ArrayList<DCTrainRecord>();
			BufferedReader tin = new BufferedReader(new FileReader(tfile
					+ ".tagged"));
			BufferedWriter rin = new BufferedWriter(new FileWriter(rfile
					+ ".raw"));	
			 PrintWriter rmap  = new PrintWriter(new FileOutputStream(rfile
						+ ".map"));
			
			boolean fixedColFormat = false;
			String rawLine;
			StringTokenizer rawTok;
			int t[] = new int[0];
			String cArray[][] = new String[0][0];
			int [][] labels = null;
			// read list of columns in the header of the tag file
			tin.mark(1000);
			String line = tin.readLine();
			  while(line!=null)
			  {
				  
			    labels = readGrammerInfo(numLabels, line, tagDelimit);
			    String c[] = new String[lexcalgrammerindex];
			    for(int i =0;i<c.length;i++)
				{
			    	c[i] = lexcalgrammer[i][0]; 	
					    }
			    td.add(new DCTrainRecord(labels, c));
			    tin.mark(1000);
		        line = tin.readLine();
			  }
			  DCTrainData ReData = new DCTrainData(td);
			  
			  for (ReData.startScan(); ReData.hasNext();) {
		          	DCTrainRecord seq =(DCTrainRecord)ReData.next();
		          	for(int i =0;i<seq._tokens.length;i++)
		          	{
		          		rin.write(seq._tokens[i]);
		          		rin.write(" ");
		          		
		          	}
		          	rin.write("\n");
		     }
			     
			    rmap.println(inverseLabelmap.size());
				for (Enumeration e =inverseLabelmap.keys() ; e.hasMoreElements() ;) {
					  Long key = (Long) e.nextElement();
					  rmap.print(key);
					  rmap.print(" ");
					  rmap.print(inverseLabelmap.get(key));  
					  rmap.print("\n");
			     }
				 rmap.println(inversecompactmap.size());
				 for (Enumeration e =inversecompactmap.keys() ; e.hasMoreElements() ;) {
					   Integer key = (Integer)e.nextElement();
					  rmap.print(key);
					  rmap.print(" ");
					  rmap.print(inversecompactmap.get(key));  
					  rmap.print("\n");
			     }
				 rmap.close();
			  
			  
			  
			  
			  rin.close();
			
			  return   ReData ;
		} catch (IOException e) {
			System.err.println("I/O Error" + e);
			System.exit(-1);
		}
	    
		
		return null;
	}
	
    public static void readRaw(Vector<String[]> data,String file,String delimit,String impDelimit) {
        try {
            BufferedReader rin=new BufferedReader(new FileReader(file+".raw"));
            String line;
            while((line=rin.readLine())!=null) {
                StringTokenizer tok=new StringTokenizer(line.toLowerCase(),delimit,true);
                String seq[]=new String[tok.countTokens()];
                int count=0;
                for(int i=0 ; i<seq.length ; i++) {
                    String tokStr=tok.nextToken();
                    if (delimit.indexOf(tokStr)==-1 || impDelimit.indexOf(tokStr)!=-1) {
                        seq[count++]=new String(tokStr);
                    } 
                }
                String aseq[]=new String[count];
                for(int i=0 ; i<count ; i++) {
                    aseq[i]=seq[i];
                }
                data.add(aseq);
            }
            rin.close();
        } catch(IOException e) {
            System.out.println("I/O Error"+e);
            System.exit(-1);
        }
    }

    /**
     * 
     * @param file
     * @param tagDelimit A character as String that acts as a delimiter between tokens and label.
     */
	public static void createRaw(String file, String tagDelimit) {
		BufferedReader in = null;
		PrintWriter out = null;
		try {
			in = new BufferedReader(new FileReader(file + ".tagged"));
			out = new PrintWriter(new FileOutputStream(file + ".raw"));
			String line;
			StringBuilder rawLine;
			rawLine = new StringBuilder(200);
            while((line=in.readLine())!=null) {
                StringTokenizer t=new StringTokenizer(line,tagDelimit);
                if(t.countTokens()<2) {
					out.println(rawLine);
					rawLine.setLength(0);
                } else {
                    rawLine.append(" ");
					rawLine.append(t.nextToken());
                }
            }
			out.println(rawLine);
		} catch (IOException e) {
			System.out.println("I/O Error" + e);
			System.exit(-1);
		} finally {
			if (in != null) {
				try { in.close();} catch (IOException e) {}
			}
			if (out != null) {
				out.close();
			}
		}
	}
}
