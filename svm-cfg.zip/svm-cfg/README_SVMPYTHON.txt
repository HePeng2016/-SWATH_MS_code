Readme for the SVM-python version 2 structure learning API
----------------------------------------------------------
Version 2.0.0
Thomas Finley, tomf@cs.cornell.edu 2007.05.21

This is a version of SVM-struct which allows one to define the user
API in Python instead of C.  See the documentation in html-docs for
more information on this program and its use.
----------------------------------------------------------
Version 2.0.1
Thomas Finley, tomf@cs.cornell.edu 2007.10.02

A fix for various critical issues.  Many of these issues did not
occur in the PowerPC OS X version, but cropped up in the Intel OS X
verison.
----------------------------------------------------------
Version 2.0.2
Thomas Finley, tomf@cs.cornell.edu 2007.10.28

Fixes related to defining custom constraints.
----------------------------------------------------------
Version 2.0.3
Thomas Finley, tomf@cs.cornell.edu 2007.12.24

Changed the svmapi module so that it includes many of the default
implementations of functions so that users may employ the default
behavior without having to implement it themselves.
----------------------------------------------------------
Version 2.0.4
Thomas Finley, tfinley@gmail.com 2010.05.29

Updated URLs and contact information since my old webpage was
defunct.  No substantial changes.
