#include"hash-templates.h"
#include"../cky/cky.h"
HASH_CODE(Hash_Int, int, double*, IDENTITY, NEQ, IDENTITY, NO_OP, 
	  0, NULL, FREE)
HASH_CODE(Hash_Long_Int,__int64,int*, IDENTITY, NEQ, IDENTITY, NO_OP, 
	  0, NULL, FREE)
HASH_CODE(Hash_Long_List,__int64,TokenList*, IDENTITY, NEQ, IDENTITY, NO_OP, 
	  0, NULL, FREE)
HASH_CODE(Dic_int, int, int*, IDENTITY, NEQ, IDENTITY, NO_OP, 
	  0, NULL, FREE)
