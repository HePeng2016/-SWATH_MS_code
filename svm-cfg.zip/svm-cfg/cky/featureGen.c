#include "cky.h"

Long featureGen_grammerMapsGetKey(int body1,int body2,int type)
{
   Long key = 0;
   key = key|type;
   key = key<<(Long_SIZE -4);
   key = key + body1*tokensize+body2;
   return key;
}
int featureGen_rulemaplambda1(PATTERN x,LABEL y,int i,int rulehead,int e1_ID,int e2_ID)
{      
	   int* result;

       result = (Hash_Long_Int_ref(grammermapLambda,((Long)rulehead)*tokensize*tokensize +((Long)e1_ID)*tokensize +(Long)e2_ID));
	   if(result!=NULL)	  
	   {
		  return *result;
	   }
	   else
	   {
	     return -1;
	   }
}

int featureGen_rulemaplambda(PATTERN x,LABEL y,int i,int j,int m,int rulehead,int e1_ID,int e2_ID)
{      
	   int* result;

       result = (Hash_Long_Int_ref(grammermapLambda,((Long)rulehead)*tokensize*tokensize +((Long)e1_ID)*tokensize +(Long)e2_ID));
	   if(result!=NULL)	  
	   {
		  return *result;
	   }
	   else
	   {
	     return -1;
	   }
}
int featureGen_lexicalrulemaplambda(PATTERN x,LABEL y,int i)
{
      Long key = 0;
	  int** Array = (int**)y.py_y+1;
      int* data = (int*)x.py_x +1;
	  int * result;

      key = key | 1;
	  key = key <<(Long_SIZE - 1);
      key = key + (Long)data[((Array)[i])[2]&MASK_SHORT_L]*tokensize; 
      key = key + (Array[i])[1];

       result = Hash_Long_Int_ref(grammermapLambda,key);
	   if(result!=NULL)
         return *(result);
	   else
	     return -1;
}



  CKYEntry * getToken_CKY(int * data, int i,double *lambda)
  {
     
      CKYEntry * result = NULL;
	  CKYEntry * temp;
	  int * tokenArray;
	  int lenght;
	  int j;
	  Long keyl;

      tokenArray = Dic_int_ref(dictionary,data[i]);
      lenght = *tokenArray;
      tokenArray = tokenArray+1;    
      
	  keyl = 0;
	  keyl = keyl|1;
      keyl = keyl <<(Long_SIZE - 1);
      keyl = keyl + data[i]*tokensize;

	  for(j=0;j<lenght;j++)
	  {
              MallocCKY(temp);
			  temp->value = lambda[*(Hash_Long_Int_ref(grammermapLambda,tokenArray[j]+keyl))];
              temp->ID = tokenArray[j];
			  temp->middle =(short)i;
			  temp->next = result;
			  result = temp;
	  }

     return result;
  }