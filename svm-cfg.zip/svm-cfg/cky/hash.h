/* hash.h
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

#include "mmm.h"

/* 
 * typedef size_t 	(*KEY_HASH)(const HASH_KEY);
 * typedef int    	(*KEY_NEQ)(const HASH_KEY, const HASH_KEY);
 * typedef HASH_KEY	(*KEY_COPY)(const HASH_KEY);
 * typedef void		(*KEY_FREE)(HASH_KEY);
 * typedef void		(*VALUE_FREE)(HASH_VALUE);
 * typedef HASH_VALUE	NULL_VALUE
 */

#define HASH_HEADER(HASH, HASH_KEY, HASH_VALUE)	\
						\
typedef struct HASH_cell {	\
  HASH_KEY	   key;		\
  size_t	   hashedkey;	\
  struct HASH_cell *next;	\
  HASH_VALUE	   value;	\
} * HASH_cell_ptr;		\
				\
typedef struct HASH_table {	/* hash table of pointers */ 	\
  HASH_cell_ptr *table;					\
  size_t 	    tablesize;	/* size of table */		\
  size_t 	    size; 	/* no of elts in hash table */	\
} * HASH;							\
	\
HASH make_HASH(size_t initial_size);	\
HASH_VALUE HASH_ref(const HASH ht, const HASH_KEY key);	\
HASH_VALUE HASH_set(HASH ht, HASH_KEY key, HASH_VALUE value);	\
HASH_VALUE HASH_delete(HASH ht, HASH_KEY key);	\
void free_HASH(HASH ht);	\
size_t HASH_size(HASH ht);	\
HASH_cell_ptr HASH_find(HASH ht, const HASH_KEY key);	\
HASH_VALUE *HASH_valuep(HASH ht, const HASH_KEY key);      	\
	\
	\
typedef struct HASHit { 	\
  HASH_KEY          key;	\
  HASH_VALUE        value;	\
  HASH		    ht;		\
  HASH_cell_ptr next;	\
  size_t            index;	\
} HASHit;			\
				\
HASHit HASHit_init(HASH ht);		\
HASHit HASHit_next(HASHit hit);	\
int HASHit_ok(HASHit hit);  

#define HASH_HEADER_ADD(HASH, HASH_KEY, HASH_VALUE)	\
							\
HASH_HEADER(HASH, HASH_KEY, HASH_VALUE)			\
HASH_VALUE HASH_inc(HASH ht, const HASH_KEY key, HASH_VALUE inc);
