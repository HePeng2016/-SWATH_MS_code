#include "cky.h"


 CKYEntry * CKY_ArrayGet(CKYEntry * list, int head) {
  
	    CKYEntry * e1 = list;
		if (list == NULL) {
			return NULL;
		}
		while (e1!=NULL){
			if(e1->ID==head)
			{
			    return e1;
			
			}
			e1 = e1->next;	
		}
		return NULL;
	}
void  initCKY(EXAMPLE  dataSeq,double * lambda)
 {
	   int lengh = *((int*)dataSeq.x.py_x);
	   int * data = (int*)dataSeq.x.py_x+1;
	   int i = 0;
	   int j = 0;
	   InitialCKYList
       CKYArrayInit(lengh,lengh);
	   for(i=0;i<lengh;i++)
	   {
		    
           CKY_Get(i,i) = getToken_CKY(data ,i,lambda);
	   }
 }

   void  CKY(EXAMPLE dataSeq,double * lambda) {
        CKYEntry *e1;
        CKYEntry *e2;
        CKYEntry *value_CKY;
        Long  key;
        int k ;
		int i;
		int m;
        TokenList * list;
		int lenght;

        lambda = lambda+1;
		initCKY(dataSeq,lambda);


        lenght = *((int*)dataSeq.x.py_x);

		for ( k = 1; k < lenght; k++) {
			for ( i = 0; i < lenght- k; i++) {
				int j = i + k;
				for ( m = i; m < j; m++) {
					if (CKY_Get(i,m) != NULL && CKY_Get(m + 1,j) != NULL){
						for ( e1 = CKY_Get(i,m);e1;e1 = e1->next) {
							for (e2 = CKY_Get(m + 1,j);e2;e2 = e2->next) {

								key = featureGen_grammerMapsGetKey(e1->ID,e2->ID, 0);
								list = featureGen_grammerMaps_get(key);
								if (list == NULL) {
									continue;
								}
								   for(;list;list = list->next){
									int rulehead = list->body;
									if ((value_CKY = CKY_ArrayGet(CKY_Get(i,j),rulehead)) == NULL) {
									    MallocCKY(value_CKY);
										value_CKY->ID = rulehead;
										value_CKY->middle = (short) m;
										value_CKY->body0 = e1->ID;
										value_CKY->body1 = e2->ID;
										value_CKY->value = e1->value + e2->value + lambda[featureGen_rulemaplambda(dataSeq.x,dataSeq.y,i,j,m,rulehead,e1->ID,e2->ID)];
										value_CKY->next = CKY_Get(i,j);
										CKY_Get(i,j) = value_CKY;
									} else {
										double temp = e1->value + e2->value + lambda[featureGen_rulemaplambda(dataSeq.x,dataSeq.y, i, j, m, rulehead, e1->ID, e2->ID)];
										if (value_CKY->value < temp) {
											value_CKY->middle = (short) m;
											value_CKY->body0 = e1->ID;
											value_CKY->body1 = e2->ID;
											value_CKY->value = temp;
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

int ** GetBestTagging()
{
     CKYEntry * e1;
	 int tokengrammerindex;
	 int i;
     int ** tokengrammerLocation;
     tokengrammerLocation = ybar_+1;
     InitCKY_Int
     Array_[0] = NULL;

	 for(e1 = CKY_Get(0,CKYArrayColLength-1);e1;e1=e1->next)
	 {
		  if( Array_[0]==NULL)
		  { 
			  if(Hash_Int_ref(root,e1->ID))
			  {
			     Array_[0] = e1;
			  
			   }
		   }else
		  {  
			  if( (Array_[0]->value < e1->value)&&Hash_Int_ref(root,e1->ID))
			  {
			       Array_[0] = e1;
			   }
		   }
	  }
      if (Array_[0] == NULL) {
			return NULL;
		}

	  tokengrammerindex = 1;
      MallocInt_3(tokengrammerLocation[0]);
      (tokengrammerLocation[0])[2] = 0;
	  (tokengrammerLocation[0])[3] = CKYArrayColLength-1;
       for (i = 0; i < tokengrammerindex; i++)
	   { 
	         if(tokengrammerLocation[i][2] != tokengrammerLocation[i][3])
			 {
			 	tokengrammerLocation[i][1] = Array_[i]->ID;
			    MallocInt_3(tokengrammerLocation[tokengrammerindex]);
                MallocInt_3(tokengrammerLocation[tokengrammerindex+1]);
			    tokengrammerLocation[tokengrammerindex][2] = tokengrammerLocation[i][2];
				tokengrammerLocation[tokengrammerindex][3] = Array_[i]->middle;
				tokengrammerLocation[tokengrammerindex+1][2] = Array_[i]->middle+1;
				tokengrammerLocation[tokengrammerindex+1][3] = tokengrammerLocation[i][3];
		        tokengrammerLocation[i][2] =((tokengrammerLocation[i][2])<<Short_SIZE) +tokengrammerindex;
				tokengrammerLocation[i][3] =((tokengrammerLocation[i][3])<<Short_SIZE) +tokengrammerindex + 1;
                 Array_[tokengrammerindex] = CKY_ArrayGet(CKY_Get(tokengrammerLocation[tokengrammerindex][2],tokengrammerLocation[tokengrammerindex][3]), Array_[i]->body0);
				 Array_[tokengrammerindex+1] = CKY_ArrayGet(CKY_Get(tokengrammerLocation[tokengrammerindex+1][2],tokengrammerLocation[tokengrammerindex+1][3]),Array_[i]->body1);   
                tokengrammerindex = tokengrammerindex+2;
			 
			  }else
			 {
				 MallocInt_2(tokengrammerLocation[i]);

				 tokengrammerLocation[i][1] = Array_[i]->ID;
				 tokengrammerLocation[i][2] = Array_[i]->middle;
			  }
	   }
   (*ybar_)[0] = tokengrammerindex+1;

  return ybar_;
}