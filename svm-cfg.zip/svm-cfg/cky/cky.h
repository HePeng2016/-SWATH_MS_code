#include "stdio.h"
#include <stdlib.h>
#include<string.h>
#include"../hash/hash.h"
#include"../svm_struct/svm_struct_common.h"

#if defined(WIN32)
typedef   __int64		Long;
#else 
typedef signed long long int	Long;

#endif
#define    Long_SIZE   64
#define    Short_SIZE  16
#define  MASK_SHORT_L   ((1<<Short_SIZE)-1)
#define  MASK_SHORT_H   ~((1<<Short_SIZE)-1)

#define  MAX_INT   1024

typedef struct CKYEntry {
  struct CKYEntry * next;
  short middle;
  int ID;
  double value;
  int body0;
  int body1;
}CKYEntry;
    int CKYEntryListFree;
	CKYEntry * CKYEntryList;
	int CKYEntryListSize;
#define InitialMallocCKYList(MAX)    {\
	   CKYEntryList =(CKYEntry*)malloc(MAX*sizeof(CKYEntry));\
       CKYEntryListSize = MAX;\
       CKYEntryListFree =0;\
	}
#define InitialCKYList  {\
       CKYEntryListFree =0;\
	}
 #define MallocCKY(Entry) \
if(CKYEntryListFree < CKYEntryListSize)\
{\
    Entry = &CKYEntryList[CKYEntryListFree];\
	Entry->next =NULL;\
	CKYEntryListFree = CKYEntryListFree+1;\
}else\
	{\
	  Entry = NULL;\
	}
CKYEntry ** CKY_Array;
int * CKY_Int;
int CKY_Int_free;
int col_size ;
int row_size ;

#define CKYArrayMallocInit(MAX)   {\
            CKY_Array = (CKYEntry**)malloc(MAX*MAX*sizeof(CKYEntry*));\
}
#define CKYArrayFree { free(CKY_Array);}
#define CKYArrayInit(m,n) {\
   row_size = n;\
   col_size = m;\
   memset(CKY_Array,0,col_size*row_size*sizeof(CKYEntry*));\
}
#define CKYArrayRowLength   row_size
#define CKYArrayColLength   col_size

#define CKY_Get(x,y)   (*(CKY_Array+(y)*col_size+(x))) 
extern  CKYEntry * CKY_ArrayGet(CKYEntry * list, int head);
#define CKY_Int_Malloc(MAX_INT){\
	      CKY_Int = (int *)malloc(MAX_INT*sizeof(int));\
          CKY_Int_free = 0;\
}
#define CKY_Int_Free  { free(CKY_Int);}
#define InitCKY_Int CKY_Int_free =0;
#define MallocInt_3(Entry) {\
	       if( CKY_Int_free<MAX_INT )\
			{Entry = CKY_Int+CKY_Int_free;\
			  *Entry = 3;\
			  CKY_Int_free = CKY_Int_free+4;}\
			  else\
			  Entry = 0;\
}
#define MallocInt_2(Entry) {\
	       if( CKY_Int_free<MAX_INT )\
			{Entry = CKY_Int+CKY_Int_free;\
              CKY_Int_free = CKY_Int_free+3;\
			  *Entry = 2;}\
			  else\
			  Entry = 0;\
}


typedef struct TrainRecord{
   int length; 
}TrainRecord;


typedef struct  TokenList{
    int body;
    struct  TokenList * next;
}TokenList;

extern  int featureGen_lexicalrulemaplambda(PATTERN x,LABEL y,int i);
extern  int featureGen_rulemaplambda (PATTERN x,LABEL y,int i,int j,int m,int rulehead,int e1_ID,int e2_ID);
extern  int featureGen_rulemaplambda1 (PATTERN x,LABEL y,int i,int rulehead,int e1_ID,int e2_ID);
extern  void  initCKY(EXAMPLE  dataSeq,double *lambda);
extern  Long featureGen_grammerMapsGetKey(int body1,int body2,int type);
extern   CKYEntry * getToken_CKY(int * dataSeq, int i,double *lambda);
//extern  TokenList * featureGen_grammerMaps_get(Long key);
extern void  CKY(EXAMPLE dataSeq,double * lambda);

#define featureGen_grammerMaps_get(key)  Hash_Long_List_ref(grammerMaps,key)
int ** GetBestTagging();
HASH_HEADER(Hash_Int,int, double*)
HASH_HEADER(Hash_Long_Int,Long,int*)
HASH_HEADER(Hash_Long_List,Long,TokenList*)
HASH_HEADER(Dic_int,int, int*)
 int tokensize;
 Hash_Int root;
 Hash_Long_Int grammermapLambda;
 Hash_Long_List grammerMaps;
 Dic_int  dictionary;
CKYEntry **Array_;
int ** ybar_;
#define Malloc_Array(MAX)   {\
	                            Array_ =(CKYEntry**)malloc(sizeof(CKYEntry*)*MAX);\
}
#define Malloc_ybar_(MAX)   {\
                               ybar_ =(int**)malloc(sizeof(int*)*MAX);\
	                           *ybar_ = (int*)malloc(sizeof(int));\
							}
#define Free_Array    {\
	                        free(Array_);\
}
#define Free_ybar_     {    free(ybar_);}