/* hash.c
 *
 * Hash tables
 *
 * make_hash: returns a new hash table
 * hash_ref: returns the object associated with a key
 * hash_set: inserts an object into a hash table
 * modified version of hash tables in "The C Programming Language", p 144
 */
 
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "mmm.h"
#include "hash.h"

/*
#define MALLOC		malloc
#define CALLOC	 	calloc
#define REALLOC 	realloc
#define FREE		free
*/

/* Preferred hash sizes - primes not close to a power of 2
 * size_t preferred_sizes[] = {7 43 277 1663 10007 60077 360497 2247673 13486051};
 */
#define preferred_size(size)		\
	(size < 21) ? 7 :		\
	(size < 129) ? 43 :		\
	(size < 831) ? 277 :		\
	(size < 4989) ? 1663 :		\
	(size < 30021) ? 10007 :	\
	(size < 180231) ? 60077 :	\
	(size < 1081491) ? 360497 :	\
	(size < 6743019) ? 2247673 :    \
	13486051
#define  HASH_KEYNEQ(a,b) (a==b)
#define  NULL_VALUE   0
#define KEY_HASH(ENTRY)  ENTRY
#define KEY_COPY(ENTRY)  ENTRY
#define KEY_FREE(ENTRY)  ENTRY


HASH make_HASH(size_t initial_size)
{
  HASH ht;
  ht = (HASH) MALLOC(sizeof(struct HASH_table));
  ht->tablesize = preferred_size(initial_size);
  ht->size = 0; 
  ht->table = (HASH_cell_ptr *)
    CALLOC(ht->tablesize, (size_t) sizeof(HASH_cell_ptr));
  return ht;
}   

/* lookup() returns a pointer to the pointer to the hash cell for this key
 * or, if the key is not present in the table, where it ought to be inserted.
 */
static HASH_cell_ptr 
*lookup(const HASH ht,  HASH_KEY key, const size_t hashedkey)
{
  HASH_cell_ptr	*p  = ht->table + hashedkey%ht->tablesize;
  
  while ( *p && 
	  ((*p)->hashedkey != hashedkey || HASH_KEYNEQ(key, (*p)->key)) )
    p = &((*p)->next);
  
  return p;
}

static void resize_hash_table(HASH ht)
{
  HASH_cell_ptr *oldtable = ht->table;
  size_t oldtablesize = ht->tablesize;
  size_t tablesize = preferred_size(ht->size);
  size_t i;
  HASH_cell_ptr	p, nextp;
  
  ht->tablesize = tablesize;
  ht->table = (HASH_cell_ptr *) 
    CALLOC(tablesize, (size_t) sizeof(HASH_cell_ptr));
  
  for (i=0; i<oldtablesize; i++)
    for (p = oldtable[i]; p; p = nextp) {
      nextp = p->next;
      p->next = ht->table[p->hashedkey%tablesize];
      ht->table[p->hashedkey%tablesize] = p;
    }
  
  FREE(oldtable);
}

HASH_VALUE   HASH_ref(const  HASH ht,const  HASH_KEY key)
{
  HASH_cell_ptr *p = lookup(ht, key, KEY_HASH(key));
  return (*p) ? (*p)->value :(HASH_VALUE)0;
}

HASH_VALUE  HASH_set(HASH ht, HASH_KEY key, HASH_VALUE value)
{
  HASH_VALUE olddata = NULL_VALUE;
  size_t hashedkey = KEY_HASH(key);
  HASH_cell_ptr *p = lookup(ht, key, hashedkey);

  if (!*p) {
    if (ht->size++ >= 3*ht->tablesize) {
      resize_hash_table(ht);
      p = lookup(ht, key, hashedkey);
      assert(!*p);
    }
    *p = MALLOC(sizeof(struct HASH_cell));
    (*p)->next = NULL;
    (*p)->hashedkey = hashedkey;
    (*p)->key = KEY_COPY(key);
  }
  else 
    olddata = (*p)->value;
  
  (*p)->value = value;
  return olddata;
}

HASH_VALUE HASH_inc(HASH ht, HASH_KEY key, HASH_VALUE inc)
{
  size_t hashedkey = KEY_HASH(key);
  HASH_cell_ptr *p = lookup(ht, key, hashedkey);
  
  if (!*p) {
    if (ht->size++ >= 3*ht->tablesize) {
      resize_hash_table(ht);
      p = lookup(ht, key, hashedkey);
      assert(!*p);
    }
    *p = MALLOC(sizeof(struct HASH_cell));
    (*p)->next = NULL_VALUE;
    (*p)->hashedkey = hashedkey;
    (*p)->key = KEY_COPY(key);
    (*p)->value = NULL_VALUE;
  }

  (*p)->value += inc;
  return (*p)->value;
}

HASH_VALUE HASH_delete(HASH ht, HASH_KEY key)
{
  HASH_VALUE olddata = NULL_VALUE;
  HASH_cell_ptr *p = lookup(ht, key, KEY_HASH(key));

  if (*p) {
    olddata = (*p)->value;
    *p = (*p)->next;
    KEY_FREE((*p)->key);
    FREE(*p);
    
    if (--ht->size < ht->tablesize/5)
      resize_hash_table(ht);
  }
  return olddata;
}

void free_HASH(HASH ht)
{
  HASH_cell_ptr p, q;
  size_t  i;
  
  for (i = 0; i < ht->tablesize; i++)
    for (p = ht->table[i]; p; p = q) {
      q = p->next;
      KEY_FREE(p->key);
      #ifdef VALUE_FREE
        VALUE_FREE(p->data);
      #endif
      FREE(p);
    }
  FREE(ht->table);
  FREE(ht);
}

