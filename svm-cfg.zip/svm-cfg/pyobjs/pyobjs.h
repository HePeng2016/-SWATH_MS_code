#ifndef __PYOBJS_H
#define __PYOBJS_H

#include "sparse.h"
#include "document.h"

#include "sparm.h"
#include "array.h"
#include "structmodel.h"
#include "model.h"
#include "kernelparm.h"
#include "sample.h"
#include "constraints.h"

#endif // __PYOBJS_H
